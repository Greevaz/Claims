using System.Windows;
using System.Windows.Media;

namespace ClaimsCalculatorApp
{
    /// <summary>
    /// Icon/tone for a <see cref="ThemedMessageBox"/>. Mirrors the subset of
    /// <see cref="MessageBoxImage"/> the app actually uses (Information,
    /// Warning, Error) so call sites read the same as before.
    /// </summary>
    public enum ThemedMessageBoxIcon
    {
        Information,
        Warning,
        Error
    }

    /// <summary>
    /// A small modal notice styled to match the rest of the app (same
    /// gradient background, rounded buttons, glass panel) instead of the
    /// plain OS <see cref="MessageBox"/>, which renders with default
    /// Windows chrome and stands out against the app's theme.
    /// </summary>
    public partial class ThemedMessageBox : Window
    {
        public bool SecondaryClicked { get; private set; }

        public ThemedMessageBox(string message, string heading, ThemedMessageBoxIcon icon,
            string okText = "OK", string? secondaryText = null)
        {
            InitializeComponent();
            TxtHeading.Text = heading;
            TxtMessage.Text = message;
            BtnOk.Content = okText;
            if (secondaryText is not null)
            {
                BtnSecondary.Content = secondaryText;
                BtnSecondary.Visibility = Visibility.Visible;
            }
            ApplyIcon(icon);
        }

        private void ApplyIcon(ThemedMessageBoxIcon icon)
        {
            var (glyph, color) = icon switch
            {
                ThemedMessageBoxIcon.Warning => ("!", "#E0A94D"),
                ThemedMessageBoxIcon.Error => ("\u2715", "#D9636C"),
                _ => ("i", "#657DB9"),
            };
            TxtIconGlyph.Text = glyph;
            IconBadge.Background = new SolidColorBrush(
                (Color)ColorConverter.ConvertFromString(color));
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e) => DialogResult = true;

        private void BtnSecondary_Click(object sender, RoutedEventArgs e)
        {
            SecondaryClicked = true;
            DialogResult = true;
        }

        /// <summary>
        /// Drop-in replacement for <c>MessageBox.Show(owner, message, heading, MessageBoxButton.OK, image)</c>.
        /// </summary>
        public static void Show(Window owner, string message, string heading,
            ThemedMessageBoxIcon icon = ThemedMessageBoxIcon.Information, string okText = "OK")
        {
            var dialog = new ThemedMessageBox(message, heading, icon, okText) { Owner = owner };
            dialog.ShowDialog();
        }

        /// <summary>
        /// Shows a dialog with a primary and a secondary button (e.g.
        /// "Go to Database Settings" / "Exit App"). Returns true if the
        /// secondary button was clicked, false for the primary button or if
        /// the dialog was dismissed another way (Esc, etc. - treated as
        /// choosing to stay/primary).
        /// </summary>
        public static bool ShowWithSecondary(Window owner, string message, string heading,
            ThemedMessageBoxIcon icon, string primaryText, string secondaryText)
        {
            var dialog = new ThemedMessageBox(message, heading, icon, primaryText, secondaryText) { Owner = owner };
            dialog.ShowDialog();
            return dialog.SecondaryClicked;
        }
    }
}
