<#
.SYNOPSIS
    Creates ClaimsData.accdb (via the ACE OLEDB provider -  no Access desktop
    app required) and imports every row of Hollard_Database.xlsx into it.

.DESCRIPTION
    This does, by script, exactly what the manual steps in the migration
    notes describe:
      1. Create a new, empty .accdb at the target path (using ADOX, which
         ships as part of the same "Microsoft Access Database Engine"
         redistributable that provides the ACE OLEDB driver -  so if the app
         can already open .accdb files, this step will work too).
      2. Run AccessSchema.sql against it to create the ClaimsData table.
      3. Read every row from Hollard_Database.xlsx (via the same ACE
         provider's Excel driver) and INSERT it into ClaimsData, with
         explicit type conversion per column (dates parsed to real
         DateTime, amounts parsed to decimal, AZ parsed to int) rather than
         relying on OLEDB's own guesswork.

    Safe to re-run: if ClaimsData.accdb already exists, database/table
    creation is skipped and the script only asks before re-importing (to
    avoid silently duplicating 5,248 rows on a second run).

.PARAMETER ExcelPath
    Path to the source Hollard_Database.xlsx.

.PARAMETER DatabasePath
    Path where ClaimsData.accdb should be created (or already exists).
    Defaults to the path already configured in appsettings.json.

.EXAMPLE
    .\Setup-AccessDatabase.ps1 -ExcelPath "P:\Public\__PostFin\Hollard Data Base\Hollard_Database.xlsx"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$ExcelPath,

    [string]$DatabasePath = "P:\Public\__PostFin\Hollard Data Base\ClaimsData.accdb",

    [string]$SchemaPath,

    [string]$SheetName = "Hollard Data Base",

    [string]$TableName = "ClaimsData"
)

$ErrorActionPreference = "Stop"

if (-not $SchemaPath) {
    # $PSScriptRoot can come back empty depending on how the script was
    # launched (e.g. "powershell -File" from inside pwsh), so fall back to
    # the invoked script's own path if needed, then to the current directory.
    $scriptDir = if ($PSScriptRoot) { $PSScriptRoot }
        elseif ($MyInvocation.MyCommand.Path) { Split-Path -Parent $MyInvocation.MyCommand.Path }
        else { (Get-Location).Path }
    $SchemaPath = Join-Path $scriptDir "AccessSchema.sql"
}

# ---------------------------------------------------------------------------
# Column plan: (Excel column letter, Access column name, conversion).
# Order and letters match Hollard_Database.xlsx exactly (A..AB) and the
# DbColumn names match AccessSchema.sql / AccessClaimsService.cs's ColumnMap.
# Conversion is one of: Int, Date, Currency, Text.
# ---------------------------------------------------------------------------
$ColumnPlan = @(
    @{ Col = "A";  Db = "AZ";                            Type = "Int" }
    @{ Col = "B";  Db = "PolicyNumber";                   Type = "Text" }
    @{ Col = "C";  Db = "ClientIdNumber";                 Type = "Text" }
    @{ Col = "D";  Db = "ClientDetails";                  Type = "Text" }
    @{ Col = "E";  Db = "LoanAmount";                     Type = "Currency" }
    @{ Col = "F";  Db = "DisbursementDate";                Type = "Date" }
    @{ Col = "G";  Db = "Product";                        Type = "Text" }
    @{ Col = "H";  Db = "BenefitClaimed";                 Type = "Text" }
    @{ Col = "I";  Db = "NotifiedDate";                    Type = "Date" }
    @{ Col = "J";  Db = "IncidentDate";                    Type = "Date" }
    @{ Col = "K";  Db = "DatePartialClaimSubmitted";       Type = "Date" }
    @{ Col = "L";  Db = "DateCompletedClaimSubmitted";     Type = "Date" }
    @{ Col = "M";  Db = "ClaimStatus";                    Type = "Text" }
    @{ Col = "N";  Db = "DateOfClaimDecisionLetter";       Type = "Date" }
    @{ Col = "O";  Db = "AmountApproved";                 Type = "Currency" }
    @{ Col = "P";  Db = "ExGratiaSubmitted";              Type = "Text" }
    @{ Col = "Q";  Db = "ExGratiaSubmissionDate";          Type = "Date" }
    @{ Col = "R";  Db = "ExGratiaApprovedDeclined";       Type = "Text" }
    @{ Col = "S";  Db = "ExGratiaAmountRequested";        Type = "Currency" }
    @{ Col = "T";  Db = "ExGratiaAmountReceived";         Type = "Currency" }
    @{ Col = "U";  Db = "LoanBalanceNotificationAmount";  Type = "Currency" }
    @{ Col = "V";  Db = "ClaimAmount";                    Type = "Currency" }
    @{ Col = "W";  Db = "MicroplusClaimedAmount";         Type = "Currency" }
    @{ Col = "X";  Db = "TotalHollardAmountReceived";     Type = "Currency" }
    @{ Col = "Y";  Db = "DateClaimPaidByHollard";          Type = "Date" }
    @{ Col = "Z";  Db = "AmountRefunded";                 Type = "Currency" }
    @{ Col = "AA"; Db = "DateRefundPaid";                  Type = "Date" }
    @{ Col = "AB"; Db = "Comments";                       Type = "Text" }
)

function Assert-AceProvider {
    $found = (New-Object System.Data.OleDb.OleDbEnumerator).GetElements() |
        Where-Object { $_.SOURCES_NAME -eq "Microsoft.ACE.OLEDB.12.0" }
    if (-not $found) {
        throw "Microsoft.ACE.OLEDB.12.0 is not registered on this machine. " +
              "Install the 'Microsoft Access Database Engine 2016 Redistributable' " +
              "(the same driver the app itself already needs) and re-run."
    }
}

function New-AccessDatabase {
    param([string]$Path)
    Write-Host "Creating empty database: $Path"
    $catalog = New-Object -ComObject ADOX.Catalog
    try {
        $catalog.Create("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=$Path;")
    }
    finally {
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($catalog)
    }
}

function Invoke-SchemaScript {
    param([string]$DbPath, [string]$SchemaFile)
    Write-Host "Creating ClaimsData table from $SchemaFile"
    $sql = Get-Content -Path $SchemaFile -Raw

    # Strip '--' comment lines; ACE's SQL parser chokes on them.
    $sqlNoComments = ($sql -split "`r?`n" | Where-Object { $_ -notmatch '^\s*--' }) -join "`n"

    $conn = New-Object System.Data.OleDb.OleDbConnection(
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=$DbPath;")
    $conn.Open()
    try {
        $cmd = $conn.CreateCommand()
        $cmd.CommandText = $sqlNoComments
        $cmd.ExecuteNonQuery() | Out-Null
    }
    finally {
        $conn.Close()
    }
}

function Get-CellConverted {
    param($RawValue, [string]$Type, [string]$RowLabel, [string]$ColLabel)

    if ($null -eq $RawValue -or $RawValue -eq [DBNull]::Value) { return [DBNull]::Value }
    $text = $RawValue.ToString().Trim()
    if ($text -eq "") { return [DBNull]::Value }

    switch ($Type) {
        "Int" {
            $parsed = 0
            if ([int]::TryParse($text, [ref]$parsed)) { return $parsed }
            throw "Row $RowLabel, column $ColLabel`: '$text' is not a whole number (AZ must be numeric)."
        }
        "Date" {
            if ($RawValue -is [DateTime]) { return $RawValue }
            $parsed = [DateTime]::MinValue
            if ([DateTime]::TryParse($text, [ref]$parsed)) { return $parsed }
            Write-Warning "Row $RowLabel, column $ColLabel`: '$text' is not a recognizable date -  stored as blank instead of failing the whole import."
            return [DBNull]::Value
        }
        "Currency" {
            $cleaned = $text -replace '[^\d\.\-]', ''
            $parsed = 0.0
            if ($cleaned -ne "" -and [double]::TryParse($cleaned, [ref]$parsed)) { return $parsed }
            Write-Warning "Row $RowLabel, column $ColLabel`: '$text' is not a recognizable amount -  stored as blank instead of failing the whole import."
            return [DBNull]::Value
        }
        default {
            return $text
        }
    }
}

function Import-ExcelRows {
    param([string]$DbPath, [string]$ExcelFile, [string]$Sheet, [string]$Table)

    $excelConn = New-Object System.Data.OleDb.OleDbConnection(
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=$ExcelFile;" +
        "Extended Properties=`"Excel 12.0 Xml;HDR=YES;IMEX=1`";")
    $accessConn = New-Object System.Data.OleDb.OleDbConnection(
        "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=$DbPath;")

    $excelConn.Open()
    $accessConn.Open()
    try {
        $dbColumns = ($ColumnPlan | ForEach-Object { $_.Db }) -join ", "
        $paramNames = ($ColumnPlan | ForEach-Object { "?" }) -join ", "
        $insertSql = "INSERT INTO [$Table] ($dbColumns) VALUES ($paramNames)"

        $selectSql = "SELECT * FROM [$Sheet`$]"
        $adapter = New-Object System.Data.OleDb.OleDbDataAdapter($selectSql, $excelConn)
        $dt = New-Object System.Data.DataTable
        $adapter.Fill($dt) | Out-Null

        Write-Host "Read $($dt.Rows.Count) rows from '$Sheet' in $ExcelFile"

        $insertCmd = $accessConn.CreateCommand()
        $insertCmd.CommandText = $insertSql
        foreach ($col in $ColumnPlan) {
            $oleType = switch ($col.Type) {
                "Int"      { [System.Data.OleDb.OleDbType]::Integer }
                "Date"     { [System.Data.OleDb.OleDbType]::Date }
                "Currency" { [System.Data.OleDb.OleDbType]::Currency }
                default    { [System.Data.OleDb.OleDbType]::VarWChar }
            }
            $param = New-Object System.Data.OleDb.OleDbParameter
            $param.OleDbType = $oleType
            if ($oleType -eq [System.Data.OleDb.OleDbType]::VarWChar) { $param.Size = 255 }
            [void]$insertCmd.Parameters.Add($param)
        }
        $insertCmd.Prepare()

        $imported = 0
        $rowNum = 1  # header is row 1 in the workbook; data starts at row 2
        foreach ($row in $dt.Rows) {
            $rowNum++
            for ($i = 0; $i -lt $ColumnPlan.Count; $i++) {
                $plan = $ColumnPlan[$i]
                $value = Get-CellConverted -RawValue $row[$i] -Type $plan.Type `
                    -RowLabel $rowNum -ColLabel $plan.Db
                $insertCmd.Parameters[$i].Value = $value
            }
            $insertCmd.ExecuteNonQuery() | Out-Null
            $imported++
            if ($imported % 500 -eq 0) { Write-Host "  ...$imported rows imported" }
        }
        Write-Host "Done: $imported rows imported into $Table."
    }
    finally {
        $excelConn.Close()
        $accessConn.Close()
    }
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
Assert-AceProvider

if (-not (Test-Path $ExcelPath)) {
    throw "Excel file not found: $ExcelPath"
}

$dbAlreadyExisted = Test-Path $DatabasePath
if (-not $dbAlreadyExisted) {
    New-AccessDatabase -Path $DatabasePath
    Invoke-SchemaScript -DbPath $DatabasePath -SchemaFile $SchemaPath
}
else {
    Write-Host "$DatabasePath already exists -  skipping create/schema steps."
    $answer = Read-Host "Import will INSERT rows into the existing ClaimsData table. Continue? (y/n)"
    if ($answer -ne "y") {
        Write-Host "Aborted."
        exit 0
    }
}

Import-ExcelRows -DbPath $DatabasePath -ExcelFile $ExcelPath -Sheet $SheetName -Table $TableName

Write-Host ""
Write-Host "Import complete. Point appsettings.json's AccessDatabasePath at:"
Write-Host "  $DatabasePath"
