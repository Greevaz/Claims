using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;

namespace ClaimsCalculatorApp;

/// <summary>
/// Talks to the "ClaimsData" table in an Access (.accdb) database over the
/// P: network share, via the ACE OLEDB provider — replacing the Excel COM
/// automation in <see cref="LocalExcelClaimsService"/>.
///
/// Unlike the Excel version, this does NOT need fuzzy/alias header matching:
/// the Access table's column names are fixed, short, ASCII identifiers
/// (Access field names are capped at 64 characters, so the long descriptive
/// Excel headers like "Client's ID Number" or the 130-character "Claim
/// Status : (...)" column were shortened when the table was created — see
/// AccessSchema.sql). ColumnMap below is the single source of truth mapping
/// each short database column back to the friendly label the UI shows and
/// searches by, so the rest of the app (which reads/writes by friendly
/// label, e.g. "Client Details", "AZ") doesn't need to change.
///
/// Because Access enforces real record-level locking, multiple users can
/// safely read and write different rows of this table at the same time —
/// something the single Excel workbook could not do.
/// </summary>
public sealed class AccessClaimsService
{
    private readonly string _databasePath;
    private readonly string _tableName;

    /// <summary>
    /// (DbColumn, DisplayLabel) pairs, in the same order as the original
    /// Excel workbook's columns, so the UI's field order doesn't change.
    /// </summary>
    private static readonly (string DbColumn, string Label)[] ColumnMap =
    {
        ("AZ", "AZ"),
        ("PolicyNumber", "Policy Number"),
        ("ClientIdNumber", "Client's ID Number"),
        ("ClientDetails", "Client Details"),
        ("LoanAmount", "Loan Amount"),
        ("DisbursementDate", "Disbursement Date"),
        ("Product", "Product"),
        ("BenefitClaimed", "Benefit Claimed"),
        ("NotifiedDate", "Notified Date"),
        ("IncidentDate", "Incident Date"),
        ("DatePartialClaimSubmitted", "Date Partial Claim Submitted"),
        ("DateCompletedClaimSubmitted", "Date Completed Claim Submitted"),
        ("ClaimStatus", "Claim Status"),
        ("DateOfClaimDecisionLetter", "Date of Claim Decision Letter"),
        ("AmountApproved", "Amount Approved as per Decision letter"),
        ("ExGratiaSubmitted", "Ex Gratia Submitted yes/no"),
        ("ExGratiaSubmissionDate", "Ex Gratia Submission Date"),
        ("ExGratiaApprovedDeclined", "Ex Gratia Approved or Declined"),
        ("ExGratiaAmountRequested", "Ex Gratia Amount requested"),
        ("ExGratiaAmountReceived", "Ex Gratia Amount Received"),
        // Despite its name this column holds an amount, not a date, in the
        // source data — carried through as-is rather than "corrected", since
        // that's what the real workbook contains.
        ("LoanBalanceNotificationAmount", "Loan Balance Notification date"),
        ("ClaimAmount", "Claim Amount"),
        ("MicroplusClaimedAmount", "Microplus Claimed Amount"),
        ("TotalHollardAmountReceived", "Total Hollard Amount Received"),
        ("DateClaimPaidByHollard", "Date Claim Paid by Hollard"),
        ("AmountRefunded", "Amount Refunded"),
        ("DateRefundPaid", "Date Refund Paid"),
        ("Comments", "Comments"),
    };

    // Columns the Access schema stores as a proper Date/Time type. Everything
    // else round-trips as plain text or numbers. (DateOfClaimDecisionLetter
    // and ExGratiaSubmissionDate were originally kept as text because an
    // early inspection suggested stray "N/A" values; a full check of every
    // row in Hollard_Database.xlsx found none — both columns are 100% real
    // dates or blank — so they're stored as Date/Time like the others.)
    private static readonly HashSet<string> DateColumns = new(StringComparer.OrdinalIgnoreCase)
    {
        "DisbursementDate", "NotifiedDate", "IncidentDate", "DatePartialClaimSubmitted",
        "DateCompletedClaimSubmitted", "DateClaimPaidByHollard", "DateRefundPaid",
        "DateOfClaimDecisionLetter", "ExGratiaSubmissionDate"
    };

    public AccessClaimsService(GraphSettings settings)
    {
        _databasePath = settings.AccessDatabasePath;
        _tableName = settings.TableName;
    }

    private string ConnectionString =>
        $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={_databasePath};";

    private static string DbColumnFor(string label) =>
        ColumnMap.FirstOrDefault(c => string.Equals(c.Label, label, StringComparison.OrdinalIgnoreCase)).DbColumn
        ?? throw new InvalidOperationException(
            $"'{label}' is not a known ClaimsData column. Known columns: {string.Join(", ", ColumnMap.Select(c => c.Label))}");

    public string[] GetHeaders() => ColumnMap.Select(c => c.Label).ToArray();

    public ClaimRecord? FindByAz(string az) => Find("AZ", az);

    public ClaimRecord? Find(string fieldName, string query)
    {
        var matches = FindAll(fieldName, query, maxResults: 1);
        return matches.Count > 0 ? matches[0] : null;
    }

    public List<ClaimRecord> FindAll(string fieldName, string query) => FindAll(fieldName, query, maxResults: null);

    private List<ClaimRecord> FindAll(string fieldName, string query, int? maxResults)
    {
        if (string.IsNullOrWhiteSpace(query))
            throw new ArgumentException("A search value is required.", nameof(query));

        EnsureDatabaseExists();
        var dbColumn = DbColumnFor(fieldName);
        var trimmedQuery = query.Trim();

        using var connection = new OleDbConnection(ConnectionString);
        connection.Open();

        // AZ is an exact numeric match; every other field is a case-insensitive
        // "contains", matching the search behaviour the Excel version had.
        string sql;
        using var command = connection.CreateCommand();
        if (string.Equals(dbColumn, "AZ", StringComparison.OrdinalIgnoreCase))
        {
            if (!int.TryParse(trimmedQuery, NumberStyles.Integer, CultureInfo.InvariantCulture, out var azValue))
                return new List<ClaimRecord>(); // AZ is numeric; a non-numeric search simply has no matches
            sql = $"SELECT * FROM [{_tableName}] WHERE [AZ] = ?";
            command.Parameters.Add(new OleDbParameter("@az", OleDbType.Integer) { Value = azValue });
        }
        else
        {
            sql = $"SELECT * FROM [{_tableName}] WHERE [{dbColumn}] LIKE ?";
            command.Parameters.Add(new OleDbParameter("@q", OleDbType.VarWChar) { Value = $"%{trimmedQuery}%" });
        }
        command.CommandText = sql;

        var records = new List<ClaimRecord>();
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            records.Add(BuildRecord(reader));
            if (maxResults is int max && records.Count >= max)
                break;
        }
        return records;
    }

    private static ClaimRecord BuildRecord(IDataRecord reader)
    {
        var headers = new string[ColumnMap.Length];
        var values = new object?[ColumnMap.Length];
        for (var i = 0; i < ColumnMap.Length; i++)
        {
            headers[i] = ColumnMap[i].Label;
            var raw = reader[ColumnMap[i].DbColumn];
            values[i] = raw is DBNull ? null : raw;
        }

        object? Value(string label)
        {
            var index = Array.FindIndex(headers, h => string.Equals(h, label, StringComparison.OrdinalIgnoreCase));
            return index >= 0 ? values[index] : null;
        }

        return new ClaimRecord
        {
            Az = Value("AZ")?.ToString() ?? "",
            PolicyNumber = Value("Policy Number")?.ToString() ?? "",
            ClientId = Value("Client's ID Number")?.ToString() ?? "",
            Name = Value("Client Details")?.ToString() ?? "",
            LoanAmount = ParseDecimal(Value("Loan Amount")),
            LoanStartDate = ParseDate(Value("Disbursement Date")),
            IncidentDate = ParseDate(Value("Incident Date")),
            Headers = headers,
            Values = values
        };
    }

    public void AddRecord(ClaimRecord newRecord)
    {
        if (string.IsNullOrWhiteSpace(newRecord.Az))
            throw new ArgumentException("AZ is required.", nameof(newRecord));
        if (!int.TryParse(newRecord.Az.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var azValue))
            throw new ArgumentException("AZ must be numeric.", nameof(newRecord));

        EnsureDatabaseExists();
        using var connection = new OleDbConnection(ConnectionString);
        connection.Open();

        using (var checkCommand = connection.CreateCommand())
        {
            checkCommand.CommandText = $"SELECT COUNT(*) FROM [{_tableName}] WHERE [AZ] = ?";
            checkCommand.Parameters.Add(new OleDbParameter("@az", OleDbType.Integer) { Value = azValue });
            if (Convert.ToInt32(checkCommand.ExecuteScalar()) > 0)
                throw new InvalidOperationException($"A client with AZ '{newRecord.Az}' already exists.");
        }

        var columnNames = string.Join(", ", ColumnMap.Select(c => $"[{c.DbColumn}]"));
        var placeholders = string.Join(", ", ColumnMap.Select(_ => "?"));

        using var insertCommand = connection.CreateCommand();
        insertCommand.CommandText = $"INSERT INTO [{_tableName}] ({columnNames}) VALUES ({placeholders})";
        for (var i = 0; i < ColumnMap.Length; i++)
        {
            var value = FindValueForHeader(newRecord, ColumnMap[i].Label, i);
            insertCommand.Parameters.Add(ToParameter(ColumnMap[i].DbColumn, value));
        }
        insertCommand.ExecuteNonQuery();
    }

    public void UpdateByAz(string az, ClaimRecord updatedRecord)
    {
        if (string.IsNullOrWhiteSpace(az))
            throw new ArgumentException("AZ is required.", nameof(az));
        if (!int.TryParse(az.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var azValue))
            throw new ArgumentException("AZ must be numeric.", nameof(az));

        EnsureDatabaseExists();
        using var connection = new OleDbConnection(ConnectionString);
        connection.Open();

        // Every column except AZ itself is updatable — AZ is the row's key
        // and the app already refuses to change it before calling this.
        var setClauses = string.Join(", ", ColumnMap
            .Where(c => !string.Equals(c.DbColumn, "AZ", StringComparison.OrdinalIgnoreCase))
            .Select(c => $"[{c.DbColumn}] = ?"));

        using var command = connection.CreateCommand();
        command.CommandText = $"UPDATE [{_tableName}] SET {setClauses} WHERE [AZ] = ?";
        for (var i = 0; i < ColumnMap.Length; i++)
        {
            if (string.Equals(ColumnMap[i].DbColumn, "AZ", StringComparison.OrdinalIgnoreCase))
                continue;
            var value = i < updatedRecord.Values.Length ? updatedRecord.Values[i] : null;
            command.Parameters.Add(ToParameter(ColumnMap[i].DbColumn, value));
        }
        command.Parameters.Add(new OleDbParameter("@az", OleDbType.Integer) { Value = azValue });

        var rowsAffected = command.ExecuteNonQuery();
        if (rowsAffected == 0)
            throw new InvalidOperationException($"No claim found for AZ '{az}'.");
    }

    private static object? FindValueForHeader(ClaimRecord record, string label, int index)
    {
        if (index < record.Headers.Length &&
            string.Equals(record.Headers[index], label, StringComparison.OrdinalIgnoreCase) &&
            index < record.Values.Length)
            return record.Values[index];

        var byName = Array.FindIndex(record.Headers, h => string.Equals(h, label, StringComparison.OrdinalIgnoreCase));
        return byName >= 0 && byName < record.Values.Length ? record.Values[byName] : null;
    }

    /// <summary>
    /// Looks up a field's value by its display label (e.g. "Client Details")
    /// across a set of <see cref="ClaimField"/> entries. Column names are
    /// fixed now, so — unlike the old Excel alias lookup — this is a plain
    /// exact match against the label.
    /// </summary>
    public static string ValueForCanonicalField(IEnumerable<ClaimField> fields, string label)
    {
        var field = fields.FirstOrDefault(item => string.Equals(item.Name, label, StringComparison.OrdinalIgnoreCase));
        return field?.Value ?? "";
    }

    private static OleDbParameter ToParameter(string dbColumn, object? value)
    {
        var text = value?.ToString()?.Trim();

        if (string.Equals(dbColumn, "AZ", StringComparison.OrdinalIgnoreCase))
        {
            return int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var az)
                ? new OleDbParameter("@AZ", OleDbType.Integer) { Value = az }
                : throw new ArgumentException("AZ must be numeric.");
        }

        if (DateColumns.Contains(dbColumn))
        {
            var date = ParseDate(value);
            return new OleDbParameter("@" + dbColumn, OleDbType.Date)
            {
                Value = (object?)date ?? DBNull.Value
            };
        }

        if (string.IsNullOrWhiteSpace(text))
            return new OleDbParameter("@" + dbColumn, OleDbType.VarWChar) { Value = DBNull.Value };

        // Amount-like columns are stored as Currency; everything else as text.
        if (dbColumn.Contains("Amount", StringComparison.OrdinalIgnoreCase) &&
            decimal.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var amount))
            return new OleDbParameter("@" + dbColumn, OleDbType.Currency) { Value = amount };

        return new OleDbParameter("@" + dbColumn, OleDbType.VarWChar) { Value = text };
    }

    private static decimal? ParseDecimal(object? value) =>
        decimal.TryParse(value?.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var parsed)
            ? parsed : null;

    private static DateTime? ParseDate(object? value)
    {
        if (value is null)
            return null;
        if (value is DateTime date)
            return date.Date;

        var text = value.ToString()?.Trim();
        if (string.IsNullOrWhiteSpace(text))
            return null;

        if (DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out var parsed) ||
            DateTime.TryParse(text, CultureInfo.CurrentCulture, DateTimeStyles.AllowWhiteSpaces, out parsed))
            return parsed.Date;

        return null; // e.g. "N/A" in one of the mixed text/date columns
    }

    private void EnsureDatabaseExists()
    {
        if (string.IsNullOrWhiteSpace(_databasePath))
            throw new InvalidOperationException("AccessDatabasePath is not set in appsettings.json.");
        if (!File.Exists(_databasePath))
            throw new FileNotFoundException(
                $"The Access database was not found on the network share. Checked: {_databasePath}", _databasePath);
    }
}
