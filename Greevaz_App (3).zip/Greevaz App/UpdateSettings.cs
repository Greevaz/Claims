using System.IO;
using System.Text.Json;

namespace ClaimsCalculatorApp;

public sealed class UpdateSettings
{
    public bool Enabled { get; init; }
    public string GitHubOwner { get; init; } = "";
    public string GitHubRepo { get; init; } = "";
    public string AssetNameContains { get; init; } = "";

    public static UpdateSettings Load()
    {
        const string fileName = "appsettings.json";
        if (!File.Exists(fileName))
            return new UpdateSettings();

        using var document = JsonDocument.Parse(File.ReadAllText(fileName));
        if (!document.RootElement.TryGetProperty("Updates", out var updates))
            return new UpdateSettings();

        return new UpdateSettings
        {
            Enabled = updates.TryGetProperty("Enabled", out var e) && e.GetBoolean(),
            GitHubOwner = updates.TryGetProperty("GitHubOwner", out var o) ? o.GetString() ?? "" : "",
            GitHubRepo = updates.TryGetProperty("GitHubRepo", out var r) ? r.GetString() ?? "" : "",
            AssetNameContains = updates.TryGetProperty("AssetNameContains", out var a) ? a.GetString() ?? "" : ""
        };
    }
}
