using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.OleDb;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace ClaimsCalculatorApp
{
    public partial class MainWindow : Window
    {
        private readonly ObservableCollection<RateChange> _rateChanges = new();
        private readonly ObservableCollection<PaymentEntry> _payments = new();
        private readonly ObservableCollection<DocumentCheckItem> _checklist = new();
        private readonly ObservableCollection<DailyRow> _scheduleRows = new();
        private readonly ObservableCollection<ClaimField> _claimFields = new();
        private readonly ObservableCollection<ClaimField> _newClientFields = new();
        private readonly RateChangesStore _rateChangesStore;

        private ScheduleResult? _lastResult;
        private AccessClaimsService? _accessClaimsService;
        private ClaimRecord? _loadedClaim;
        private bool _loadingRateChanges;
        private bool _newClientFieldsLoaded;

        // Unsaved-changes tracking for the database "Browse/Edit" and "Create/Add" tabs.
        private bool _browseEditDirty;
        private bool _createAddDirty;
        private bool _loadingClaimFields;
        private bool _loadingNewClientFields;
        private bool _isClosingConfirmed;

        // True whenever the app can't currently reach a valid ClaimsData.accdb.
        // While true, navigation away from Settings is blocked so the user
        // can't get "stuck" on a broken database without realizing it.
        private bool _databaseLocationInvalid;

        private void SetLoading(bool isLoading, string message = "Please wait...")
        {
            TxtLoadingMessage.Text = message;
            LoadingOverlay.Visibility = isLoading ? Visibility.Visible : Visibility.Collapsed;
        }

        public MainWindow()
        {
            InitializeComponent();
            Closing += MainWindow_Closing;

            // Keep database-driven dates and opening balance blank until a claim is loaded.
            DpStartDate.SelectedDate = null;
            DpDateOfDeath.SelectedDate = null;
            DpLoanAgreementDate.SelectedDate = null;
            TxtSingleRate.Text = "0.00";
            TxtOpeningBalance.Text = "";
            SetClaimInputsEnabled(false);
            UpdateInterestRateVisibility();

            // The rate list is stored next to the shared claims workbook (see
            // appsettings.json -> Graph.LocalWorkbookPath) so it's the same
            // universal list for everyone and survives app updates. If
            // settings can't be read yet, RateChangesStore falls back to a
            // stable per-machine location instead of the app's build folder.
            GraphSettings? graphSettings = null;
            try
            {
                graphSettings = GraphSettings.Load();
            }
            catch
            {
                // No/invalid appsettings.json yet — RateChangesStore will fall back.
            }
            _rateChangesStore = new RateChangesStore(graphSettings);

            GridRateChanges.ItemsSource = _rateChanges;
            _rateChanges.CollectionChanged += RateChanges_CollectionChanged;
            _loadingRateChanges = true;
            try
            {
                foreach (var change in _rateChangesStore.Load())
                    _rateChanges.Add(change);
            }
            finally
            {
                _loadingRateChanges = false;
            }
            GridPayments.ItemsSource = _payments;
            GridSchedule.ItemsSource = _scheduleRows;
            ItemsClaimFields.ItemsSource = _claimFields;
            ItemsNewClientFields.ItemsSource = _newClientFields;

            foreach (var name in DocumentChecklistEngine.DocNames)
            {
                var item = new DocumentCheckItem(name, isChecked: true);
                item.PropertyChanged += Checklist_PropertyChanged;
                _checklist.Add(item);
            }
            ChecklistItemsControl.ItemsSource = _checklist;
            TxtStatus.Text = "";

            CheckDatabaseLocationAtStartup();
        }

        /// <summary>
        /// Validates that AccessDatabasePath (per-user override or
        /// appsettings.json default) actually points at a reachable, openable
        /// .accdb before the user can do anything else. If it doesn't, locks
        /// the app onto Settings -> Database Access Location until it's fixed.
        /// </summary>
        private void CheckDatabaseLocationAtStartup()
        {
            var error = GetDatabaseLocationError();
            if (error is null)
                return;

            _databaseLocationInvalid = true;

            HomeGrid.Visibility = Visibility.Collapsed;
            MainTabs.Visibility = Visibility.Collapsed;
            DatabaseGrid.Visibility = Visibility.Collapsed;
            BtnClaimsBack.Visibility = Visibility.Collapsed;
            SettingsGrid.Visibility = Visibility.Visible;
            RefreshDbLocationTab();
            SettingsTabs.SelectedItem = DatabaseLocationTab;
            TxtStatus.Text = "Database location needs to be set before the app can be used.";

            var exitClicked = ThemedMessageBox.ShowWithSecondary(this,
                $"{error}\n\nSet a working location for ClaimsData.accdb below to continue.",
                "Database not found", ThemedMessageBoxIcon.Warning,
                primaryText: "Go to Database Settings", secondaryText: "Exit App");

            if (exitClicked)
            {
                Application.Current.Shutdown();
            }
        }
        /// <summary>
        /// Returns null if the currently-configured AccessDatabasePath points
        /// at a file that exists and can actually be opened via the ACE OLEDB
        /// provider, otherwise a human-readable reason it can't be used.
        /// </summary>
        private static string? GetDatabaseLocationError()
        {
            string path;
            try
            {
                path = GraphSettings.Load().AccessDatabasePath;
            }
            catch (Exception ex)
            {
                return $"App settings could not be read: {ex.Message}";
            }

            if (string.IsNullOrWhiteSpace(path))
                return "No database location is configured yet.";

            if (!File.Exists(path))
                return $"'{path}' could not be found. It may have been moved, renamed, or the network drive/share isn't reachable right now.";

            try
            {
                using var connection = new OleDbConnection($"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path};");
                connection.Open();
            }
            catch (Exception ex)
            {
                return $"'{path}' was found but could not be opened as a database: {ex.Message}";
            }

            return null;
        }

        private void BtnOpenClaimsCalculator_Click(object sender, RoutedEventArgs e)
        {
            HomeGrid.Visibility = Visibility.Collapsed;
            MainTabs.Visibility = Visibility.Visible;
            DatabaseGrid.Visibility = Visibility.Collapsed;
            BtnClaimsBack.Visibility = Visibility.Visible;
            MainTabs.SelectedItem = ClaimsCalculatorTab;
            TxtStatus.Text = "Claims Calculator and Cover Page opened.";
        }

        private void BtnOpenSettings_Click(object sender, RoutedEventArgs e)
        {
            HomeGrid.Visibility = Visibility.Collapsed;
            DatabaseGrid.Visibility = Visibility.Collapsed;
            MainTabs.Visibility = Visibility.Collapsed;
            SettingsGrid.Visibility = Visibility.Visible;
            RefreshDbLocationTab();
            TxtStatus.Text = "Settings opened.";
        }

        /// <summary>
        /// Fills in the "Database Access Location" tab with whatever path is
        /// currently in effect (the saved per-user override if there is one,
        /// otherwise appsettings.json's default) and a note on which one it is.
        /// </summary>
        private void RefreshDbLocationTab()
        {
            var userOverride = UserSettings.Load().AccessDatabasePath;
            if (!string.IsNullOrWhiteSpace(userOverride))
            {
                TxtDbLocation.Text = userOverride;
                TxtDbLocationSource.Text = "This is a custom location saved for this user. Use \"Reset to Default\" to go back to the app's standard location.";
            }
            else
            {
                try
                {
                    TxtDbLocation.Text = GraphSettings.Load().AccessDatabasePath;
                }
                catch
                {
                    TxtDbLocation.Text = "";
                }
                TxtDbLocationSource.Text = "This is the app's default location (from appsettings.json).";
            }
        }

        private void BtnBrowseDbLocation_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Select ClaimsData.accdb",
                Filter = "Access Database (*.accdb)|*.accdb|All files (*.*)|*.*",
                CheckFileExists = true
            };

            var initialPath = TxtDbLocation.Text;
            if (!string.IsNullOrWhiteSpace(initialPath) && Directory.Exists(Path.GetDirectoryName(initialPath)))
                dialog.InitialDirectory = Path.GetDirectoryName(initialPath);

            if (dialog.ShowDialog(this) == true)
                TxtDbLocation.Text = dialog.FileName;
        }

        private void BtnSaveDbLocation_Click(object sender, RoutedEventArgs e)
        {
            var path = TxtDbLocation.Text.Trim();
            if (string.IsNullOrWhiteSpace(path))
            {
                ThemedMessageBox.Show(this, "Choose a .accdb file first.", "No location selected",
                    ThemedMessageBoxIcon.Warning);
                return;
            }

            if (!File.Exists(path))
            {
                ThemedMessageBox.Show(this, $"'{path}' could not be found. Double-check the path (or the network drive/share is reachable) and try again.",
                    "File not found", ThemedMessageBoxIcon.Warning);
                return;
            }

            var settings = UserSettings.Load();
            settings.AccessDatabasePath = path;
            settings.Save();

            // Force the next database call to build a fresh AccessClaimsService
            // against the newly saved path instead of reusing the old connection.
            _accessClaimsService = null;

            RefreshDbLocationTab();

            if (GetDatabaseLocationError() is null)
            {
                ReevaluateDatabaseLock();
                ThemedMessageBox.Show(this, "Database location saved. This will be used the next time the app connects to the database, and every time it starts from now on.",
                    "Saved", ThemedMessageBoxIcon.Information);
                TxtStatus.Text = "Database access location saved.";
            }
            else
            {
                // Saved, but the file isn't actually a workable database (e.g. exists
                // but can't be opened) - ReevaluateDatabaseLock reports why and keeps
                // the app locked here rather than claiming success.
                ReevaluateDatabaseLock();
            }
        }

        private void BtnResetDbLocation_Click(object sender, RoutedEventArgs e)
        {
            var settings = UserSettings.Load();
            if (string.IsNullOrWhiteSpace(settings.AccessDatabasePath))
                return; // already on the default

            settings.AccessDatabasePath = null;
            settings.Save();
            _accessClaimsService = null;

            RefreshDbLocationTab();

            if (GetDatabaseLocationError() is null)
            {
                ReevaluateDatabaseLock();
                ThemedMessageBox.Show(this, "Reverted to the app's default database location.", "Reset",
                    ThemedMessageBoxIcon.Information);
                TxtStatus.Text = "Database access location reset to default.";
            }
            else
            {
                ReevaluateDatabaseLock();
            }
        }

        /// <summary>
        /// Re-checks the database location after Save/Reset in the Settings
        /// tab. If it's now valid and the app was locked, unlocks it and
        /// returns to Home; if it's still invalid, keeps the app locked onto
        /// this tab (and stays quiet if it was never locked to begin with,
        /// since this can also run for a user just changing an already-working
        /// location).
        /// </summary>
        private void ReevaluateDatabaseLock()
        {
            var error = GetDatabaseLocationError();

            if (error is null)
            {
                if (_databaseLocationInvalid)
                {
                    _databaseLocationInvalid = false;
                    SettingsGrid.Visibility = Visibility.Collapsed;
                    HomeGrid.Visibility = Visibility.Visible;
                    TxtStatus.Text = "Database connected.";
                }
                return;
            }

            _databaseLocationInvalid = true;
            ThemedMessageBox.Show(this, error, "Still not reachable", ThemedMessageBoxIcon.Warning);
        }

        private void BtnOpenDatabaseRecords_Click(object sender, RoutedEventArgs e)
        {
            HomeGrid.Visibility = Visibility.Collapsed;
            MainTabs.Visibility = Visibility.Collapsed;
            DatabaseGrid.Visibility = Visibility.Visible;
            TxtDatabaseSearch.Focus();
            TxtStatus.Text = "Enter an AZ to load a database record.";
        }

        private async void BtnBackToHome_Click(object sender, RoutedEventArgs e)
        {
            if (_databaseLocationInvalid)
            {
                SettingsGrid.Visibility = Visibility.Visible;
                MainTabs.Visibility = Visibility.Collapsed;
                DatabaseGrid.Visibility = Visibility.Collapsed;
                HomeGrid.Visibility = Visibility.Collapsed;
                SettingsTabs.SelectedItem = DatabaseLocationTab;
                var exitClicked = ThemedMessageBox.ShowWithSecondary(this,
                    "A working database location is required before you can use the app. Set one below to continue.",
                    "Database not set", ThemedMessageBoxIcon.Warning,
                    primaryText: "OK", secondaryText: "Exit App");
                if (exitClicked)
                    Application.Current.Shutdown();
                return;
            }

            // Only the database screen has the Browse/Edit and Create/Add tabs, so only
            // prompt for unsaved changes when navigating home from there.
            if (DatabaseGrid.Visibility == Visibility.Visible &&
                !await ConfirmProceedWithUnsavedChangesAsync())
                return;

            DatabaseGrid.Visibility = Visibility.Collapsed;
            SettingsGrid.Visibility = Visibility.Collapsed;
            MainTabs.Visibility = Visibility.Collapsed;
            BtnClaimsBack.Visibility = Visibility.Collapsed;
            HomeGrid.Visibility = Visibility.Visible;
            TxtStatus.Text = "";
        }

        /// <summary>
        /// Checks the Browse/Edit and Create/Add tabs for unsaved edits and, if any are
        /// found, prompts the user to Save, Discard, or Cancel. Returns true when it's
        /// safe to proceed (nothing unsaved, or the user resolved it), false when the
        /// user chose Cancel (or closed the prompt) and the caller should stay put.
        /// </summary>
        private async Task<bool> ConfirmProceedWithUnsavedChangesAsync()
        {
            if (_browseEditDirty)
            {
                var dialog = new UnsavedChangesDialog(
                    "You have unsaved changes on the Browse/Edit tab. Do you want to save?")
                { Owner = this };

                if (dialog.ShowDialog() != true)
                    return false;

                if (dialog.Result == UnsavedChangesResult.Save)
                {
                    if (!await SaveClaimFieldsAsync())
                        return false;
                }
                else
                {
                    DiscardClaimFieldEdits();
                }
            }

            if (_createAddDirty)
            {
                var dialog = new UnsavedChangesDialog(
                    "You have unsaved changes on the Create/Add tab. Do you want to save?")
                { Owner = this };

                if (dialog.ShowDialog() != true)
                    return false;

                if (dialog.Result == UnsavedChangesResult.Save)
                {
                    if (!await AddNewClientToDatabaseAsync())
                        return false;
                }
                else
                {
                    ResetNewClientFields();
                }
            }

            return true;
        }

        private async void BtnSearchDatabase_Click(object sender, RoutedEventArgs e)
        {
            var query = TxtDatabaseSearch.Text.Trim();
            var selectedField = ((System.Windows.Controls.ComboBoxItem)CmbDatabaseSearchField.SelectedItem).Content.ToString()!;
            // The dropdown shows friendly labels, but the Excel table's actual
            // columns are named "Client Details" and "Client's ID Number" (same
            // names used everywhere else in the app) — map to those before searching.
            var fieldName = selectedField switch
            {
                "Name" => "Client Details",
                "Client ID" => "Client's ID Number",
                _ => selectedField
            };
            if (string.IsNullOrWhiteSpace(query))
            {
                TxtStatus.Text = "Enter a search value.";
                return;
            }

            try
            {
                SetLoading(true);
                TxtStatus.Text = "Loading database record...";
                _accessClaimsService ??= new AccessClaimsService(GraphSettings.Load());
                var matches = await Task.Run(() => _accessClaimsService.FindAll(fieldName, query));

                ClaimRecord? claim;
                if (matches.Count == 0)
                {
                    claim = null;
                }
                else if (matches.Count == 1)
                {
                    claim = matches[0];
                }
                else
                {
                    var picker = new ClientPickerWindow(matches) { Owner = this };
                    if (picker.ShowDialog() != true || picker.SelectedClaim is null)
                    {
                        TxtStatus.Text = $"{matches.Count} records matched {selectedField} '{query}' — none selected.";
                        return;
                    }
                    claim = picker.SelectedClaim;
                }

                if (claim is null)
                {
                    _loadedClaim = null;
                    ClearClaimFields();
                    TxtStatus.Text = $"No record found for {selectedField} '{query}'.";
                    ThemedMessageBox.Show(this, $"No record found for {selectedField} '{query}'.",
                        "No Client Found", ThemedMessageBoxIcon.Information);
                    return;
                }

                _loadedClaim = claim;
                PopulateClaimFields(claim);
                TxtStatus.Text = $"Loaded database record for {claim.Name}.";
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"Excel load failed: {ex.Message}";
            }
            finally
            {
                SetLoading(false);
            }
        }

        private void TxtDatabaseSearch_PreviewTextInput(object sender,
            System.Windows.Input.TextCompositionEventArgs e) =>
            e.Handled = IsDatabaseAzSearch() &&
                        e.Text.Any(character => !char.IsDigit(character));

        private void TxtDatabaseSearch_Pasting(object sender, System.Windows.DataObjectPastingEventArgs e)
        {
            if (!e.DataObject.GetDataPresent(typeof(string)) ||
                e.DataObject.GetData(typeof(string)) is not string pasted ||
                (IsDatabaseAzSearch() && pasted.Any(character => !char.IsDigit(character))))
                e.CancelCommand();
        }

        private bool IsDatabaseAzSearch() =>
            CmbDatabaseSearchField.SelectedIndex == 0;

        private void TxtDatabaseSearch_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                e.Handled = true;
                BtnSearchDatabase_Click(sender, new RoutedEventArgs());
            }
        }

        private static readonly string[] ProductOptions =
        {
            "Pensioner", "Debit Order", "GIPF Pensioner", "Payroll",
            "Government", "Smartcard Salary", "War Vet"
        };

        private static readonly string[] BenefitClaimedOptions =
        {
            "Death", "Loss of Income", "Disability", "Dread Disease"
        };

        private static readonly string[] ClaimStatusOptions =
        {
            "Notification Sent", "Claim Approved", "Repudiated",
            "Partial Claim Submitted", "Completed Claim Submitted", "Claim Finalized"
        };

        private static readonly string[] YesNoOptions = { "Yes", "No" };
        private static readonly string[] ApprovedDeclinedOptions = { "Approved", "Declined" };

        private static ClaimField BuildNewClientField(string header)
        {
            var name = header.Trim();
            var lower = name.ToLowerInvariant();
            var (kind, options) = ClassifyField(name);

            object? initial = kind == ClaimFieldKind.YesNo
                ? "No"
                : kind == ClaimFieldKind.Date && lower.Contains("notified")
                    ? DateTime.Today
                    : null;

            return new ClaimField(name, initial, kind, options);
        }

        private static (ClaimFieldKind Kind, IReadOnlyList<string> Options) ClassifyField(string header)
        {
            var name = header.Trim();
            var lower = name.ToLowerInvariant();
            var isDateHeader = lower.Contains("date");
            var isExGratia = lower.Contains("ex gratia") || lower.Contains("exgratia");

            if (lower == "product")
                return (ClaimFieldKind.Dropdown, ProductOptions);
            if (lower == "benefit claimed")
                return (ClaimFieldKind.Dropdown, BenefitClaimedOptions);
            if (lower.StartsWith("claim status"))
                return (ClaimFieldKind.Dropdown, ClaimStatusOptions);
            if (isExGratia && !isDateHeader &&
                (lower.Contains("yes/no") || lower.Contains("yes / no") || lower.Contains("submitted")))
                return (ClaimFieldKind.YesNo, YesNoOptions);
            if (isExGratia && !isDateHeader &&
                (lower.Contains("approved") || lower.Contains("declined")))
                return (ClaimFieldKind.ApprovedDeclined, ApprovedDeclinedOptions);
            if (isDateHeader)
                return (ClaimFieldKind.Date, Array.Empty<string>());

            return (ClaimFieldKind.Text, Array.Empty<string>());
        }

        private void PopulateClaimFields(ClaimRecord claim)
        {
            foreach (var field in _claimFields)
                field.PropertyChanged -= ClaimField_PropertyChanged;

            _loadingClaimFields = true;
            try
            {
                _claimFields.Clear();
                for (var i = 0; i < claim.Headers.Length; i++)
                {
                    var header = claim.Headers[i];
                    var (kind, options) = ClassifyField(header);
                    var rawValue = i < claim.Values.Length ? claim.Values[i] : null;
                    var field = new ClaimField(header, rawValue, kind, options);
                    field.PropertyChanged += ClaimField_PropertyChanged;
                    _claimFields.Add(field);
                }
            }
            finally
            {
                _loadingClaimFields = false;
            }
            _browseEditDirty = false;
        }

        private void ClearClaimFields()
        {
            foreach (var field in _claimFields)
                field.PropertyChanged -= ClaimField_PropertyChanged;
            _claimFields.Clear();
            _browseEditDirty = false;
        }

        private void ClaimField_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (_loadingClaimFields)
                return;
            if (e.PropertyName == nameof(ClaimField.Value))
                _browseEditDirty = true;
        }

        // Reverts the Browse/Edit tab back to the last-loaded (saved) values.
        private void DiscardClaimFieldEdits()
        {
            if (_loadedClaim is null)
            {
                ClearClaimFields();
                return;
            }

            PopulateClaimFields(_loadedClaim);
            TxtStatus.Text = $"Changes discarded. Reloaded database record for {_loadedClaim.Name}.";
        }

        private async void DatabaseTabs_SelectionChanged(object sender,
            System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (e.Source == DatabaseTabs && DatabaseTabs.SelectedItem == CreateAddTab && !_newClientFieldsLoaded)
                await LoadNewClientFieldsAsync();
        }

        private async Task LoadNewClientFieldsAsync()
        {
            try
            {
                SetLoading(true, "Loading database fields...");
                _accessClaimsService ??= new AccessClaimsService(GraphSettings.Load());
                var headers = await Task.Run(() => _accessClaimsService.GetHeaders());
                _loadingNewClientFields = true;
                try
                {
                    _newClientFields.Clear();
                    foreach (var header in headers)
                    {
                        var field = BuildNewClientField(header);
                        field.PropertyChanged += NewClientField_PropertyChanged;
                        _newClientFields.Add(field);
                    }
                }
                finally
                {
                    _loadingNewClientFields = false;
                }
                _newClientFieldsLoaded = true;
                _createAddDirty = false;
                TxtStatus.Text = "Enter the new client's details, then click Add to Database.";
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"Could not load database fields: {ex.Message}";
            }
            finally
            {
                SetLoading(false);
            }
        }

        private async void BtnAddToDatabase_Click(object sender, RoutedEventArgs e)
        {
            await AddNewClientToDatabaseAsync();
        }

        private async Task<bool> AddNewClientToDatabaseAsync()
        {
            if (_newClientFields.Count == 0)
            {
                ThemedMessageBox.Show(this, "The database fields have not loaded yet. Please try again.",
                    "Unsuccessful", ThemedMessageBoxIcon.Warning);
                return false;
            }

            string ValueFor(string name) =>
                AccessClaimsService.ValueForCanonicalField(_newClientFields, name);

            var az = ValueFor("AZ").Trim();
            if (string.IsNullOrWhiteSpace(az))
            {
                ThemedMessageBox.Show(this, "The AZ field is required to add a client to the database.",
                    "Unsuccessful", ThemedMessageBoxIcon.Warning);
                return false;
            }

            try
            {
                SetLoading(true, "Adding client to the database...");
                _accessClaimsService ??= new AccessClaimsService(GraphSettings.Load());

                var headers = _newClientFields.Select(field => field.Name).ToArray();
                var values = _newClientFields.Select(field => (object?)field.Value).ToArray();

                var parsedAmount = decimal.TryParse(ValueFor("Loan Amount"), NumberStyles.Number,
                    CultureInfo.InvariantCulture, out var amount) ? amount : (decimal?)null;
                var parsedLoanDate = DateTime.TryParse(ValueFor("Disbursement Date"),
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var loanDate) ? loanDate : (DateTime?)null;
                var parsedIncidentDate = DateTime.TryParse(ValueFor("Incident Date"),
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var incidentDate) ? incidentDate : (DateTime?)null;

                var newRecord = new ClaimRecord
                {
                    Az = az,
                    PolicyNumber = ValueFor("Policy Number"),
                    ClientId = ValueFor("Client's ID Number"),
                    Name = ValueFor("Client Details"),
                    LoanAmount = parsedAmount,
                    LoanStartDate = parsedLoanDate,
                    IncidentDate = parsedIncidentDate,
                    Headers = headers,
                    Values = values
                };

                await Task.Run(() => _accessClaimsService.AddRecord(newRecord));

                var displayName = string.IsNullOrWhiteSpace(newRecord.Name) ? az : newRecord.Name;
                TxtStatus.Text = $"Added new client {displayName} to the database.";
                ThemedMessageBox.Show(this, $"Client '{displayName}' was added to the database successfully.",
                    "Successful", ThemedMessageBoxIcon.Information);

                ResetNewClientFields();
                return true;
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"Add to database failed: {ex.Message}";
                ThemedMessageBox.Show(this, $"The client could not be added to the database.\n\nReason: {ex.Message}",
                    "Unsuccessful", ThemedMessageBoxIcon.Error);
                return false;
            }
            finally
            {
                SetLoading(false);
            }
        }

        private void BtnClearNewClient_Click(object sender, RoutedEventArgs e) => ResetNewClientFields();

        private void ResetNewClientFields()
        {
            var headers = _newClientFields.Select(field => field.Name).ToArray();
            foreach (var field in _newClientFields)
                field.PropertyChanged -= NewClientField_PropertyChanged;

            _loadingNewClientFields = true;
            try
            {
                _newClientFields.Clear();
                foreach (var header in headers)
                {
                    var field = BuildNewClientField(header);
                    field.PropertyChanged += NewClientField_PropertyChanged;
                    _newClientFields.Add(field);
                }
            }
            finally
            {
                _loadingNewClientFields = false;
            }
            _createAddDirty = false;
        }

        private void NewClientField_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (_loadingNewClientFields)
                return;
            if (e.PropertyName == nameof(ClaimField.Value))
                _createAddDirty = true;
        }

        private void BtnAddRate_Click(object sender, RoutedEventArgs e)
        {
            var change = new RateChange { EffectiveDate = DateTime.Today, NewRatePercent = 0 };
            _rateChanges.Add(change);
            CalculateClaims();
        }

        private void BtnRemoveRate_Click(object sender, RoutedEventArgs e)
        {
            if (GridRateChanges.SelectedItem is RateChange rc)
            {
                _rateChanges.Remove(rc);
                CalculateClaims();
            }
        }

        private void RateChanges_CollectionChanged(object? sender,
            System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.OldItems is not null)
                foreach (RateChange change in e.OldItems)
                    change.PropertyChanged -= RateChange_PropertyChanged;
            if (e.NewItems is not null)
                foreach (RateChange change in e.NewItems)
                    change.PropertyChanged += RateChange_PropertyChanged;
            SaveRateChanges();
        }

        private void RateChange_PropertyChanged(object? sender,
            System.ComponentModel.PropertyChangedEventArgs e)
        {
            SaveRateChanges();
            CalculateClaims();
        }

        private void GridRateChanges_CellEditEnding(object sender,
            System.Windows.Controls.DataGridCellEditEndingEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                GridRateChanges.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Cell, true);
                GridRateChanges.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Row, true);
                SaveRateChanges();
                CalculateClaims();
            }));
        }

        private void BtnSaveRates_Click(object sender, RoutedEventArgs e)
        {
            GridRateChanges.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Cell, true);
            GridRateChanges.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Row, true);
            SaveRateChanges();
            TxtStatus.Text = "Rate changes saved.";
        }

        private void GridRateChanges_PreviewTextInput(object sender,
            System.Windows.Input.TextCompositionEventArgs e)
        {
            if (GridRateChanges.CurrentColumn?.Header?.ToString() == "New Rate (%)")
            {
                var textBox = e.OriginalSource as System.Windows.Controls.TextBox;
                var proposed = textBox is null ? e.Text : textBox.Text.Insert(textBox.SelectionStart, e.Text);
                e.Handled = proposed.Any(character => !char.IsDigit(character) && character != '.');
            }
        }

        private void GridRateChanges_Pasting(object sender,
            System.Windows.DataObjectPastingEventArgs e)
        {
            if (GridRateChanges.CurrentColumn?.Header?.ToString() == "New Rate (%)" &&
                (!e.DataObject.GetDataPresent(typeof(string)) ||
                 e.DataObject.GetData(typeof(string)) is not string pasted ||
                 pasted.Any(character => !char.IsDigit(character) && character != '.')))
                e.CancelCommand();
        }

        private void RateTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.TextBox textBox)
                textBox.SelectAll();
        }

        private void RateTextBox_PreviewTextInput(object sender,
            System.Windows.Input.TextCompositionEventArgs e)
        {
            if (sender is not System.Windows.Controls.TextBox textBox)
                return;
            var proposed = textBox.Text.Remove(textBox.SelectionStart, textBox.SelectionLength)
                .Insert(textBox.SelectionStart, e.Text);
            e.Handled = proposed.Any(character => !char.IsDigit(character) && character != '.');
        }

        private void RateTextBox_Pasting(object sender, System.Windows.DataObjectPastingEventArgs e)
        {
            if (sender is System.Windows.Controls.TextBox &&
                (!e.DataObject.GetDataPresent(typeof(string)) ||
                 e.DataObject.GetData(typeof(string)) is not string pasted ||
                 pasted.Any(character => !char.IsDigit(character) && character != '.')))
                e.CancelCommand();
        }

        private async void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            // Prompt for unsaved Browse/Edit or Create/Add changes before the window
            // actually closes. WPF can't await inside Closing without cancelling first,
            // so we cancel, resolve the prompt(s), then re-trigger Close() ourselves.
            if (!_isClosingConfirmed && (_browseEditDirty || _createAddDirty))
            {
                e.Cancel = true;
                if (!await ConfirmProceedWithUnsavedChangesAsync())
                    return;

                _isClosingConfirmed = true;
                Close();
                return;
            }

            GridRateChanges.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Cell, true);
            GridRateChanges.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Row, true);
            SaveRateChanges();
        }

        private void SaveRateChanges()
        {
            if (!_loadingRateChanges)
            {
                try
                {
                    _rateChangesStore.Save(_rateChanges);
                }
                catch (Exception ex)
                {
                    TxtStatus.Text = $"Rate changes could not be saved: {ex.Message}";
                }
            }
        }

        private void BtnAddPayment_Click(object sender, RoutedEventArgs e)
        {
            var payment = new PaymentEntry { Date = DateTime.Today, Amount = 0 };
            payment.PropertyChanged += Payment_PropertyChanged;
            _payments.Add(payment);
            CalculateClaims();
        }

        private void BtnRemovePayment_Click(object sender, RoutedEventArgs e)
        {
            if (GridPayments.SelectedItem is PaymentEntry p)
            {
                p.PropertyChanged -= Payment_PropertyChanged;
                _payments.Remove(p);
                CalculateClaims();
            }
        }

        private void GridPayments_CellEditEnding(object sender, System.Windows.Controls.DataGridCellEditEndingEventArgs e)
        {
            Dispatcher.BeginInvoke(new Action(CalculateClaims));
        }

        private void DecimalTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.TextBox textBox)
                textBox.SelectAll();
        }

        private void DecimalTextBox_PreviewTextInput(object sender,
            System.Windows.Input.TextCompositionEventArgs e)
        {
            if (sender is not System.Windows.Controls.TextBox textBox)
                return;

            var proposed = textBox.Text.Remove(textBox.SelectionStart, textBox.SelectionLength)
                .Insert(textBox.SelectionStart, e.Text);
            e.Handled = !IsValidDecimalInput(proposed);
        }

        private void DecimalTextBox_Pasting(object sender, System.Windows.DataObjectPastingEventArgs e)
        {
            if (sender is not System.Windows.Controls.TextBox textBox ||
                !e.DataObject.GetDataPresent(typeof(string)) ||
                e.DataObject.GetData(typeof(string)) is not string pasted)
            {
                e.CancelCommand();
                return;
            }

            var proposed = textBox.Text.Remove(textBox.SelectionStart, textBox.SelectionLength)
                .Insert(textBox.SelectionStart, pasted);
            if (!IsValidDecimalInput(proposed))
                e.CancelCommand();
        }

        private static bool IsValidDecimalInput(string text) =>
            text.Count(character => character == '.') <= 1 &&
            text.All(character => char.IsDigit(character) || character == '.');

        private void PaymentDateChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            CalculateClaims();
        }

        private void Payment_PropertyChanged(object? sender,
            System.ComponentModel.PropertyChangedEventArgs e) => CalculateClaims();

        private void Checklist_PropertyChanged(object? sender,
            System.ComponentModel.PropertyChangedEventArgs e) => CalculateClaims();

        private void ClaimInputChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) =>
            CalculateClaims();

        private void ClaimDateChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) =>
            CalculateClaims();

        private void ClaimOptionChanged(object sender, RoutedEventArgs e)
        {
            UpdateInterestRateVisibility();
            CalculateClaims();
        }

        // The single "Interest Rate" field only applies when Fixed Interest
        // Rate is ticked. When it's unticked, the rate comes from the
        // Interest Rate Changes list in Settings instead, so hide the field
        // rather than leave a control on screen that no longer does anything.
        private void UpdateInterestRateVisibility()
        {
            var isFixedRate = ChkMultipleRates.IsChecked == true;
            var visibility = isFixedRate ? Visibility.Visible : Visibility.Collapsed;
            LblSingleRate.Visibility = visibility;
            TxtSingleRate.Visibility = visibility;
        }

        private async void BtnSearchClaim_Click(object sender, RoutedEventArgs e)
        {
            var az = TxtAccountRefNo.Text.Trim();
            if (string.IsNullOrWhiteSpace(az))
            {
                _loadedClaim = null;
                SetClaimInputsEnabled(false);
                TxtStatus.Text = "Enter an AZ to search.";
                return;
            }

            try
            {
                SetLoading(true);
                SetClaimInputsEnabled(false);
                TxtStatus.Text = "Loading claim from Excel...";
                var service = _accessClaimsService ??= new AccessClaimsService(GraphSettings.Load());
                var claim = await Task.Run(() => service.FindByAz(az));
                ApplyLoadedClaim(claim, az);
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"Excel load failed: {ex.Message}";
            }
            finally
            {
                SetLoading(false);
            }
        }

        private async void BtnImportClaim_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Title = "Import Statement (PDF)",
                Filter = "PDF files (*.pdf)|*.pdf",
                CheckFileExists = true,
                CheckPathExists = true,
                Multiselect = false
            };

            if (dialog.ShowDialog() != true)
                return;

            try
            {
                SetLoading(true, "Scanning statement...");
                TxtStatus.Text = "Scanning PDF statement...";

                var result = await Task.Run(() => StatementImportService.Parse(dialog.FileName));

                // Don't populate anything from a statement that didn't parse
                // cleanly — a partial or empty parse is worse than no import
                // at all, since it would silently mix good and missing data.
                var missingFields = new System.Collections.Generic.List<string>();
                if (string.IsNullOrWhiteSpace(result.AccountNo)) missingFields.Add("Account No");
                if (string.IsNullOrWhiteSpace(result.ReferenceNo)) missingFields.Add("Reference No");
                if (string.IsNullOrWhiteSpace(result.ClientName)) missingFields.Add("Client Name");
                if (result.StartDate is null) missingFields.Add("Start Date");
                if (result.Transactions.Count == 0) missingFields.Add("Transactions");

                if (missingFields.Count > 0)
                {
                    TxtStatus.Text = "Statement import failed: partial or no data was recognised in that statement " +
                        $"(missing: {string.Join(", ", missingFields)}). Nothing was populated.";
                    ThemedMessageBox.Show(this,
                        "Partial or no data was retrieved from the statement, so nothing was populated.\n\n" +
                        $"Missing: {string.Join(", ", missingFields)}",
                        "Incomplete Statement", ThemedMessageBoxIcon.Warning);
                    return;
                }

                // AZ comes from the statement's "Account No" — look it up in the
                // database before populating anything. If it isn't found, stop
                // here rather than fill the form with data tied to an unknown AZ.
                var az = result.AccountNo!.Trim();
                var service = _accessClaimsService ??= new AccessClaimsService(GraphSettings.Load());
                var claim = await Task.Run(() => service.FindByAz(az));
                if (claim is null)
                {
                    TxtStatus.Text = $"Statement import failed: no claim was found in the database for AZ '{az}'. Nothing was populated.";
                    ThemedMessageBox.Show(this, $"The AZ '{az}' on the imported statement does not exist in the database. Nothing was populated.",
                        "AZ Not Found", ThemedMessageBoxIcon.Warning);
                    return;
                }

                // AZ comes from the statement's "Account No", Policy No from its
                // "Reference no." — these are two separate values on the statement.
                TxtAccountRefNo.Text = result.AccountNo;
                TxtPolicyNo.Text = result.ReferenceNo;
                TxtClientName.Text = result.ClientName;
                DpLoanAgreementDate.SelectedDate = result.StartDate;

                _loadedClaim = claim;
                SetClaimInputsEnabled(true);
                _claimFields.Clear();
                for (var i = 0; i < claim.Headers.Length; i++)
                {
                    var value = i < claim.Values.Length ? claim.Values[i] : null;
                    _claimFields.Add(new ClaimField(claim.Headers[i], value));
                }
                var incidentDate = claim.IncidentDate?.Date;
                DpDateOfDeath.SelectedDate = incidentDate;

                // Statement Start Date is the first of the incident date's month
                // (e.g. incident 15/05/2026 -> statement start date 01/05/2026).
                DateTime? statementStartDate = incidentDate is DateTime incident
                    ? new DateTime(incident.Year, incident.Month, 1)
                    : null;
                DpStartDate.SelectedDate = statementStartDate;

                // Opening balance is derived from the last "Interest" posting
                // before the statement start date: the balance at that point
                // becomes the opening balance.
                var lastInterest = result.Transactions
                    .Where(t => string.Equals(t.Description.Trim(), "Interest", StringComparison.OrdinalIgnoreCase))
                    .Where(t => statementStartDate is not DateTime cutoffDate || t.Date < cutoffDate)
                    .OrderBy(t => t.Date)
                    .LastOrDefault();

                if (lastInterest?.Balance is decimal lastInterestBalance)
                    TxtOpeningBalance.Text = lastInterestBalance.ToString("0.00", CultureInfo.InvariantCulture);

                // Payments Received is reset to every credit from the statement
                // start date up to (and including) the incident date — not
                // filtered by description, since everything in that window is
                // being handed to this app's own calculation. Credits after the
                // incident date aren't part of the claim period, so they're
                // excluded even though they appear on the statement.
                _payments.Clear();
                var addedPayments = 0;
                if (statementStartDate is DateTime cutoff)
                {
                    foreach (var transaction in result.Transactions.OrderBy(t => t.Date))
                    {
                        if (transaction.Date >= cutoff &&
                            (incidentDate is not DateTime incidentCutoff || transaction.Date <= incidentCutoff) &&
                            transaction.Credit is decimal creditAmount && creditAmount > 0)
                        {
                            _payments.Add(new PaymentEntry { Date = transaction.Date, Amount = creditAmount });
                            addedPayments++;
                        }
                    }
                }

                var debitCount = result.Transactions.Count(t => t.Debit is > 0);
                var creditCount = result.Transactions.Count(t => t.Credit is > 0);

                TxtStatus.Text = incidentDate is null
                    ? $"Statement scanned — {debitCount} debit(s), {creditCount} credit(s) found, but the claim has no incident date set to derive the statement start date from."
                    : $"Statement scanned — incident date {incidentDate:dd/MM/yyyy}, " +
                      $"statement start date {statementStartDate:dd/MM/yyyy}, {addedPayments} credit(s) added to Payments Received.";
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"Statement import failed: {ex.Message}";
            }
            finally
            {
                SetLoading(false);
            }
        }

        private void TxtAccountRefNo_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                e.Handled = true;
                BtnSearchClaim_Click(sender, new RoutedEventArgs());
            }
        }

        private void SetClaimInputsEnabled(bool isEnabled)
        {
            TxtClientName.IsEnabled = isEnabled;
            TxtPolicyNo.IsEnabled = isEnabled;
            TxtOpeningBalance.IsEnabled = isEnabled;
            DpLoanAgreementDate.IsEnabled = isEnabled;
            DpStartDate.IsEnabled = isEnabled;
            DpDateOfDeath.IsEnabled = isEnabled;
            TxtSingleRate.IsEnabled = isEnabled;
            ChkMultipleRates.IsEnabled = isEnabled;
            TxtClaimsOfficer.IsEnabled = isEnabled;
            TxtSupervisor.IsEnabled = isEnabled;
            PaymentsTab.IsEnabled = isEnabled;
            ChecklistTab.IsEnabled = isEnabled;
            ResultsTab.IsEnabled = isEnabled;
            CoverLetterTab.IsEnabled = isEnabled;
        }

        private void ApplyLoadedClaim(ClaimRecord? claim, string az)
        {
            if (claim is null)
            {
                _loadedClaim = null;
                SetClaimInputsEnabled(false);
                TxtStatus.Text = $"No claim found for AZ '{az}'.";
                ThemedMessageBox.Show(this, $"The searched AZ '{az}' does not exist in the database.",
                    "AZ Not Found", ThemedMessageBoxIcon.Warning);
                return;
            }

            _loadedClaim = claim;
            SetClaimInputsEnabled(true);
            _claimFields.Clear();
            for (var i = 0; i < claim.Headers.Length; i++)
            {
                var value = i < claim.Values.Length ? claim.Values[i] : null;
                _claimFields.Add(new ClaimField(claim.Headers[i], value));
            }
            TxtClientName.Text = claim.Name;
            TxtPolicyNo.Text = claim.PolicyNumber;
            // Opening Balance is entered separately and is never loaded from Excel.
            TxtOpeningBalance.Text = "";
            // Map each date field to its corresponding Excel database column.
            DpLoanAgreementDate.SelectedDate = claim.LoanStartDate?.Date;
            DpStartDate.SelectedDate = null;
            DpDateOfDeath.SelectedDate = claim.IncidentDate?.Date;

            TxtStatus.Text = $"Loaded claim for {claim.Name}.";
        }

        private async void BtnSaveClaim_Click(object sender, RoutedEventArgs e)
        {
            await SaveClaimFieldsAsync();
        }

        private async Task<bool> SaveClaimFieldsAsync()
        {
            if (_loadedClaim is null)
            {
                TxtStatus.Text = "Load a claim first, then save it.";
                return false;
            }

            try
            {
                SetLoading(true);
                TxtStatus.Text = "Saving claim to Excel...";
                _accessClaimsService ??= new AccessClaimsService(GraphSettings.Load());
                var values = _claimFields.Select(field => (object?)field.Value).ToArray();
                string valueFor(string name) =>
                    AccessClaimsService.ValueForCanonicalField(_claimFields, name);
                var parsedAmount = decimal.TryParse(valueFor("Loan Amount"), NumberStyles.Number,
                    CultureInfo.InvariantCulture, out var amount) ? amount : (decimal?)null;
                var parsedLoanDate = DateTime.TryParse(valueFor("Disbursement Date"),
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var loanDate) ? loanDate : (DateTime?)null;
                var parsedIncidentDate = DateTime.TryParse(valueFor("Incident Date"),
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var incidentDate) ? incidentDate : (DateTime?)null;
                var updated = new ClaimRecord
                {
                    Az = valueFor("AZ"),
                    PolicyNumber = valueFor("Policy Number"),
                    ClientId = valueFor("Client's ID Number"),
                    Name = valueFor("Client Details"),
                    LoanAmount = parsedAmount,
                    LoanStartDate = parsedLoanDate,
                    IncidentDate = parsedIncidentDate,
                    Headers = _loadedClaim.Headers,
                    Values = values
                };
                if (string.IsNullOrWhiteSpace(updated.Az) ||
                    !string.Equals(updated.Az, _loadedClaim.Az, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("The AZ value cannot be changed.");
                await Task.Run(() => _accessClaimsService.UpdateByAz(_loadedClaim.Az, updated));
                _loadedClaim = updated;
                _browseEditDirty = false;
                TxtStatus.Text = "Claim saved to the Excel database.";
                return true;
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"Excel save failed: {ex.Message}";
                ThemedMessageBox.Show(this, $"The claim could not be saved.\n\nReason: {ex.Message}",
                    "Unsuccessful", ThemedMessageBoxIcon.Error);
                return false;
            }
            finally
            {
                SetLoading(false);
            }
        }

        private void CalculateClaims()
        {
            TxtStatus.Text = "";

            if (!decimal.TryParse(TxtOpeningBalance.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out var openingBalance))
            {
                TxtStatus.Text = "Opening Balance must be a valid number.";
                return;
            }

            if (!decimal.TryParse(TxtSingleRate.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out var singleRate))
            {
                TxtStatus.Text = "Interest Rate must be a valid number.";
                return;
            }

            if (DpStartDate.SelectedDate is null || DpDateOfDeath.SelectedDate is null)
            {
                TxtStatus.Text = "Start Date and Date of Death are required.";
                return;
            }

            var startDate = DpStartDate.SelectedDate.Value;
            var dateOfDeath = DpDateOfDeath.SelectedDate.Value;

            if (dateOfDeath.Date < startDate.Date)
            {
                TxtStatus.Text = "Date of Death cannot be before Start Date.";
                return;
            }

            var result = ClaimsCalculatorEngine.CalculateSchedule(
                openingBalance,
                startDate,
                dateOfDeath,
                singleRate,
                ChkMultipleRates.IsChecked != true,
                _rateChanges,
                _payments);

            _lastResult = result;

            _scheduleRows.Clear();
            foreach (var row in result.Rows)
                _scheduleRows.Add(row);

            TxtTotalInterest.Text = $"N$ {result.TotalInterest:#,##0.00}";
            TxtClaimAmount.Text = $"N$ {result.ClaimAmountInclInterest:#,##0.00}";

            GenerateCoverLetter();
            TxtStatus.Text = $"Calculated {result.Rows.Count} day(s).";
        }

        private void GenerateCoverLetter()
        {
            if (_lastResult is null)
            {
                return;
            }

            var (present, outstanding) = DocumentChecklistEngine.Evaluate(
                _checklist.Select(c => c.IsChecked).ToList());
            var finalRate = _lastResult.Rows.LastOrDefault()?.InterestRatePercent ?? 0m;

            var input = new CoverLetterInput
            {
                ClientName = TxtClientName.Text,
                AccountRefNo = TxtAccountRefNo.Text,
                PolicyNo = TxtPolicyNo.Text,
                LoanAgreementDate = DpLoanAgreementDate.SelectedDate ?? DateTime.Today,
                DateOfDeath = DpDateOfDeath.SelectedDate ?? DateTime.Today,
                ClaimAmountInclInterest = _lastResult.ClaimAmountInclInterest,
                InterestRatePercent = finalRate,
                PresentDocuments = present,
                OutstandingDocuments = outstanding,
                ClaimsOfficerName = string.IsNullOrWhiteSpace(TxtClaimsOfficer.Text) ? "Claims Officer" : TxtClaimsOfficer.Text,
                SupervisorName = string.IsNullOrWhiteSpace(TxtSupervisor.Text) ? "Supervisor" : TxtSupervisor.Text
            };

            TxtLetterOutput.Text = CoverLetterGenerator.Generate(input);
            TxtStatus.Text = "Cover letter generated.";
        }

        private async void BtnPrintLetter_Click(object sender, RoutedEventArgs e)
        {
            if (_lastResult is null)
            {
                TxtStatus.Text = "Run the calculation first, then print.";
                return;
            }

            if (string.IsNullOrWhiteSpace(TxtLetterOutput.Text))
                GenerateCoverLetter();

            var templatePath = Path.Combine(AppContext.BaseDirectory,
                "Assets", "Letterhead PF_01 September 2026.docx");
            if (!File.Exists(templatePath))
            {
                TxtStatus.Text = $"The letterhead template was not found: {templatePath}";
                return;
            }

            var letterText = TxtLetterOutput.Text;
            var calculationData = new CalculationPrintData(
                TxtClientName.Text,
                TxtAccountRefNo.Text,
                TxtOpeningBalance.Text,
                _lastResult.TotalInterest,
                _lastResult.ClaimAmountInclInterest,
                _lastResult.Rows.ToList());
            SetLoading(true, "Printing");
            try
            {
                await PrintDocumentsOnStaThread(templatePath, letterText, calculationData);
                TxtStatus.Text = "Cover letter and claims calculation sent to the printer.";
            }
            catch (Exception ex)
            {
                TxtStatus.Text = $"Printing failed: {ex.Message}";
            }
            finally
            {
                SetLoading(false);
            }
        }

        private void PrintDocuments(string templatePath, string letterText, CalculationPrintData calculationData)
        {
            dynamic? word = null;
            dynamic? letterDocument = null;
            dynamic? calculationDocument = null;
            try
            {
                var wordType = Type.GetTypeFromProgID("Word.Application")
                    ?? throw new InvalidOperationException("Microsoft Word is not installed.");
                word = Activator.CreateInstance(wordType)
                    ?? throw new InvalidOperationException("Microsoft Word could not be started.");
                word.Visible = false;
                word.ScreenUpdating = false;
                word.DisplayAlerts = 0; // wdAlertsNone

                // The template is never saved, so opening it read-only avoids a document lock.
                letterDocument = word.Documents.Open(templatePath, ReadOnly: true, AddToRecentFiles: false);
                dynamic letterBody = letterDocument.Range(letterDocument.Content.Start,
                    letterDocument.Content.End - 1);
                var letterLines = letterText.Replace("\r\n", "\n").Split("\n");
                var claimsOfficerTitle = Array.FindIndex(letterLines, line => line.Trim() == "Claims Officer");
                var signatureStart = claimsOfficerTitle > 0 ? claimsOfficerTitle - 1 : Math.Max(0, letterLines.Length - 4);
                var signatureParts = letterLines[signatureStart].Split("\t", StringSplitOptions.None);
                var signatureTitles = letterLines[signatureStart + 1].Split("\t", StringSplitOptions.None);
                var letterBodyText = string.Join("\r", letterLines.Take(signatureStart));
                var letterBodyStart = letterDocument.Content.Start;
                letterBody.Text = letterBodyText;
                letterBody.Font.Name = "Arial";
                letterBody.Font.Size = 10;
                letterBody.Font.Bold = false;
                letterBody.ParagraphFormat.SpaceAfter = 0;
                letterBody.ParagraphFormat.LineSpacingRule = 0;

                // Only the three policy-identification lines are emphasized. Their tab
                // stop keeps every client value aligned away from its label.
                foreach (var label in new[] { "Life Assured:", "Policy No:", "Loan Account Number:" })
                {
                    var lineStart = letterBodyText.IndexOf(label, StringComparison.Ordinal);
                    if (lineStart < 0)
                        continue;

                    var lineEnd = letterBodyText.IndexOf('\r', lineStart);
                    if (lineEnd < 0)
                        lineEnd = letterBodyText.Length;

                    dynamic identificationRange = letterDocument.Range(
                        letterBodyStart + lineStart, letterBodyStart + lineEnd);
                    identificationRange.Font.Bold = true;
                    identificationRange.ParagraphFormat.TabStops.Add(216);
                }
                dynamic signatureRange = letterDocument.Range(letterDocument.Content.End - 1, letterDocument.Content.End - 1);
                dynamic signatureTable = letterDocument.Tables.Add(signatureRange, 2, 2);
                signatureTable.Borders.Enable = 0;
                signatureTable.AllowAutoFit = false;
                signatureTable.PreferredWidth = 468;
                signatureTable.Rows.Alignment = 0;
                signatureTable.Columns[1].Width = 234;
                signatureTable.Columns[2].Width = 234;
                signatureTable.Cell(1, 1).Range.Text = signatureParts[0].Trim();
                signatureTable.Cell(1, 2).Range.Text = signatureParts.Length > 1 ? signatureParts[1].Trim() : "";
                signatureTable.Cell(2, 1).Range.Text = signatureTitles[0].Trim();
                signatureTable.Cell(2, 2).Range.Text = signatureTitles.Length > 1 ? signatureTitles[1].Trim() : "";
                signatureTable.Cell(1, 1).Range.ParagraphFormat.Alignment = 0;
                signatureTable.Cell(2, 1).Range.ParagraphFormat.Alignment = 0;
                signatureTable.Cell(1, 2).Range.ParagraphFormat.Alignment = 2;
                signatureTable.Cell(2, 2).Range.ParagraphFormat.Alignment = 2;
                signatureTable.Range.Font.Name = "Arial";
                signatureTable.Range.Font.Size = 10;
                signatureTable.Range.Font.Bold = false;
                letterDocument.PrintOut();
                letterDocument.Close(false);
                letterDocument = null;

                calculationDocument = word.Documents.Add();
                BuildCalculationDocument(calculationDocument, calculationData);
                calculationDocument.PrintOut();
                calculationDocument.Close(false);
                calculationDocument = null;

                word.Quit();
                word = null;
            }
            finally
            {
                try { letterDocument?.Close(false); } catch { }
                try { calculationDocument?.Close(false); } catch { }
                try { word?.Quit(); } catch { }
            }
        }

        private Task PrintDocumentsOnStaThread(string templatePath, string letterText,
            CalculationPrintData calculationData)
        {
            var completion = new TaskCompletionSource<object?>(
                TaskCreationOptions.RunContinuationsAsynchronously);
            var worker = new Thread(() =>
            {
                try
                {
                    PrintDocuments(templatePath, letterText, calculationData);
                    completion.TrySetResult(null);
                }
                catch (Exception ex)
                {
                    completion.TrySetException(ex);
                }
            })
            {
                IsBackground = true,
                Name = "Word printing"
            };

            worker.SetApartmentState(ApartmentState.STA);
            worker.Start();
            return completion.Task;
        }

        private sealed record CalculationPrintData(string ClientName, string AccountRefNo, string OpeningBalance, decimal TotalInterest, decimal ClaimAmountInclInterest, List<DailyRow> Rows);

        private void BuildCalculationDocument(dynamic document, CalculationPrintData data)
        {
            dynamic range = document.Content;
            range.Text = $"CLAIMS CALCULATION\rClient: {data.ClientName}\rAZ: {data.AccountRefNo}\r" +
                         $"Opening Balance: {data.OpeningBalance}\rTotal Interest: {data.TotalInterest:#,##0.00}\r" +
                         $"Claim Amount Including Interest: {data.ClaimAmountInclInterest:#,##0.00}\r\n";
            range.Collapse(0);

            var tableLines = new List<string>(data.Rows.Count + 1)
            {
                "Date\tOpening Balance\tRate %\tDaily Interest\tPayments\tClosing Balance"
            };
            foreach (var row in data.Rows)
            {
                tableLines.Add(string.Join("\t", new[]
                {
                    row.Date.ToString("dd/MM/yyyy"), row.OpeningBalance.ToString("#,##0.00"),
                    row.InterestRatePercent.ToString("0.00"), row.DailyInterest.ToString("#,##0.00"),
                    row.Payments.ToString("#,##0.00"), row.ClosingBalance.ToString("#,##0.00")
                }));
            }

            // Populate the full table as a single Word operation. Filling six cells per
            // daily row makes thousands of slow cross-process COM calls for long claims.
            var tableText = string.Join("\r", tableLines);
            var tableStart = range.Start;
            range.Text = tableText;
            dynamic tableRange = document.Range(tableStart, tableStart + tableText.Length);
            dynamic table = tableRange.ConvertToTable(Separator: 1, NumColumns: 6);
            table.Style = "Table Grid";
            table.Borders.Enable = 1;
            table.AllowAutoFit = true;

            table.Rows[1].Range.Bold = true;
            table.Rows[1].Range.Shading.BackgroundPatternColor = 0xD9EAF7;
            table.Range.ParagraphFormat.SpaceAfter = 3;
            table.Range.Font.Size = 9;
        }
        private void BtnCopyLetter_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TxtLetterOutput.Text))
            {
                Clipboard.SetText(TxtLetterOutput.Text);
                TxtStatus.Text = "Letter copied to clipboard.";
            }
        }
    }
}
