using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;

namespace ClaimsCalculatorApp;

public sealed class LocalExcelClaimsService
{
    private readonly string _workbookPath;
    private readonly string _tableName;

    public LocalExcelClaimsService(GraphSettings settings)
    {
        _workbookPath = settings.LocalWorkbookPath;
        _tableName = settings.TableName;
    }

    // Excel column headers are often typed by hand and can pick up stray
    // whitespace, wrapped line breaks (Alt+Enter), or curly apostrophes that
    // make an exact, literal string comparison fail even though the header
    // is "obviously" the right one to a person reading it. Normalizing before
    // comparing (and reporting the real headers on failure) makes column
    // lookups resilient to that, and easy to diagnose when it still fails.
    private static string NormalizeHeader(string? header)
    {
        if (string.IsNullOrWhiteSpace(header))
            return "";
        var collapsed = System.Text.RegularExpressions.Regex.Replace(header, @"\s+", " ").Trim();
        return collapsed.Replace("'", "").Replace("\u2019", "");
    }

    private static bool HeaderMatches(string? candidate, string target) =>
        string.Equals(NormalizeHeader(candidate), NormalizeHeader(target), StringComparison.OrdinalIgnoreCase);

    private static int FindHeaderIndex(string[] headers, string target) =>
        Array.FindIndex(headers, h => HeaderMatches(h, target));

    // The Excel table's columns are sometimes retyped slightly differently
    // from what the code originally expected (e.g. "Client Name" instead of
    // "Client Details", "Client ID Number" instead of "Client's ID Number",
    // "Policy No" instead of "Policy Number"). A single hardcoded header name
    // then fails to resolve even though a column that clearly holds the same
    // data exists, silently leaving the field blank everywhere it's read
    // (search results, the client picker, "Load from SharePoint", etc).
    // Known variants are tried in order, and the first one present in the
    // workbook wins, so the app tolerates the column being labelled any of
    // the common ways without needing the spreadsheet to be renamed.
    private static readonly Dictionary<string, string[]> HeaderAliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["AZ"] = new[] { "AZ" },
        ["Policy Number"] = new[] { "Policy Number", "Policy No", "Policy No.", "PolicyNumber" },
        ["Client's ID Number"] = new[]
        {
            "Client's ID Number", "Clients ID Number", "Client ID Number", "Client ID", "ID Number"
        },
        ["Client Details"] = new[] { "Client Details", "Client Name", "Name", "Client" },
        ["Loan Amount"] = new[] { "Loan Amount", "Loan Amount (N$)", "Amount" },
        ["Disbursement Date"] = new[] { "Disbursement Date", "Loan Start Date", "Loan Agreement Date" },
        ["Incident Date"] = new[] { "Incident Date", "Date of Death", "Date of Incident" },
    };

    // Resolves a canonical field name to whichever column is actually
    // present in the workbook, trying each known alias in turn. Falls back
    // to the canonical name itself for fields with no known aliases.
    private static int FindHeaderIndexWithAliases(string[] headers, string canonicalName)
    {
        var candidates = HeaderAliases.TryGetValue(canonicalName, out var aliases)
            ? aliases
            : new[] { canonicalName };

        foreach (var candidate in candidates)
        {
            var index = FindHeaderIndex(headers, candidate);
            if (index >= 0)
                return index;
        }

        return -1;
    }

    // Reads the header row and cleans up each header (trim/collapse whitespace)
    // so labels shown in the UI and used for matching are tidy either way.
    private static string[] GetHeaderRow(object? headerValues) =>
        ToRow(headerValues).Select(NormalizeHeader).ToArray();

    public ClaimRecord? FindByAz(string az)
        => Find("AZ", az);

    public List<ClaimRecord> FindAll(string fieldName, string query)
    {
        if (string.IsNullOrWhiteSpace(query))
            throw new ArgumentException("A search value is required.", nameof(query));

        EnsureWorkbookExists();
        dynamic? excel = null;
        dynamic? workbook = null;
        dynamic? sheet = null;
        dynamic? table = null;
        dynamic? headersRange = null;
        dynamic? dataRange = null;

        try
        {
            excel = Activator.CreateInstance(Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException("Microsoft Excel is not installed."))
                ?? throw new InvalidOperationException("Failed to start Microsoft Excel.");
            excel.Visible = false;
            excel.DisplayAlerts = false;
            workbook = excel.Workbooks.Open(_workbookPath, ReadOnly: true);
            var tableInfo = FindTable((object)workbook);
            sheet = tableInfo.Sheet;
            table = tableInfo.Table;
            headersRange = table.HeaderRowRange;
            dataRange = table.DataBodyRange;
            return FindAllRecords(headersRange!.Value2, dataRange?.Value2, fieldName, query);
        }
        finally
        {
            CloseExcel(excel, workbook, sheet, table, headersRange, dataRange);
        }
    }

    public ClaimRecord? Find(string fieldName, string query)
    {
        if (string.IsNullOrWhiteSpace(query))
            throw new ArgumentException("A search value is required.", nameof(query));

        EnsureWorkbookExists();
        dynamic? excel = null;
        dynamic? workbook = null;
        dynamic? sheet = null;
        dynamic? table = null;
        dynamic? headersRange = null;
        dynamic? dataRange = null;

        try
        {
            excel = Activator.CreateInstance(Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException("Microsoft Excel is not installed."))
                ?? throw new InvalidOperationException("Failed to start Microsoft Excel.");
            excel.Visible = false;
            excel.DisplayAlerts = false;
            workbook = excel.Workbooks.Open(_workbookPath, ReadOnly: true);
            var tableInfo = FindTable((object)workbook);
            sheet = tableInfo.Sheet;
            table = tableInfo.Table;
            headersRange = table.HeaderRowRange;
            dataRange = table.DataBodyRange;
            return FindRecord(headersRange!.Value2, dataRange?.Value2, fieldName, query);
        }
        finally
        {
            CloseExcel(excel, workbook, sheet, table, headersRange, dataRange);
        }
    }

    public string[] GetHeaders()
    {
        EnsureWorkbookExists();
        dynamic? excel = null;
        dynamic? workbook = null;
        dynamic? sheet = null;
        dynamic? table = null;
        dynamic? headersRange = null;

        try
        {
            excel = Activator.CreateInstance(Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException("Microsoft Excel is not installed."))
                ?? throw new InvalidOperationException("Failed to start Microsoft Excel.");
            excel.Visible = false;
            excel.DisplayAlerts = false;
            workbook = excel.Workbooks.Open(_workbookPath, ReadOnly: true);
            var tableInfo = FindTable((object)workbook);
            sheet = tableInfo.Sheet;
            table = tableInfo.Table;
            headersRange = table.HeaderRowRange;
            string[] headers = GetHeaderRow(headersRange!.Value2);
            return headers;
        }
        finally
        {
            CloseExcel(excel, workbook, sheet, table, headersRange);
        }
    }

    public void AddRecord(ClaimRecord newRecord)
    {
        if (string.IsNullOrWhiteSpace(newRecord.Az))
            throw new ArgumentException("AZ is required.", nameof(newRecord));

        EnsureWorkbookExists();
        dynamic? excel = null;
        dynamic? workbook = null;
        dynamic? sheet = null;
        dynamic? table = null;
        dynamic? headersRange = null;
        dynamic? dataRange = null;
        dynamic? newRow = null;

        try
        {
            excel = Activator.CreateInstance(Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException("Microsoft Excel is not installed."))
                ?? throw new InvalidOperationException("Failed to start Microsoft Excel.");
            excel.Visible = false;
            excel.DisplayAlerts = false;
            workbook = excel.Workbooks.Open(_workbookPath, ReadOnly: false);
            var tableInfo = FindTable((object)workbook);
            sheet = tableInfo.Sheet;
            table = tableInfo.Table;
            headersRange = table.HeaderRowRange;
            dataRange = table.DataBodyRange;

            string[] headers = GetHeaderRow(headersRange!.Value2);
            var azColumn = FindHeaderIndex(headers, "AZ");
            if (azColumn < 0)
                throw new InvalidOperationException(
                    $"The {_tableName} table must contain an AZ column. Found columns: {string.Join(", ", headers)}");

            if (dataRange is not null)
            {
                var existingValues = dataRange.Value2;
                if (FindRowIndex(headers, existingValues, azColumn, newRecord.Az) >= 0)
                    throw new InvalidOperationException($"A client with AZ '{newRecord.Az}' already exists.");
            }

            newRow = table.ListRows.Add();
            dynamic rowRange = newRow.Range;
            for (var column = 0; column < headers.Length; column++)
            {
                var value = FindValueForHeader(newRecord, headers[column], column);
                rowRange.Cells[1, column + 1].Value2 = ToExcelValue(value);
            }

            workbook.Save();
        }
        finally
        {
            CloseExcel(excel, workbook, sheet, table, headersRange, dataRange, newRow);
        }
    }

    private static object? FindValueForHeader(ClaimRecord record, string header, int index)
    {
        if (index < record.Headers.Length &&
            HeaderMatches(record.Headers[index], header) &&
            index < record.Values.Length)
            return record.Values[index];

        var byName = FindHeaderIndexWithAliases(record.Headers, header);
        return byName >= 0 && byName < record.Values.Length ? record.Values[byName] : null;
    }

    /// <summary>
    /// Looks up a field's value by its canonical name (e.g. "Client Details",
    /// "Client's ID Number") across a set of <see cref="ClaimField"/> entries
    /// whose <c>Name</c> is whatever the workbook actually calls that column.
    /// Used anywhere the UI needs to read a specific field out of a loaded
    /// or in-progress record by canonical name instead of by position.
    /// </summary>
    public static string ValueForCanonicalField(IEnumerable<ClaimField> fields, string canonicalName)
    {
        var candidates = HeaderAliases.TryGetValue(canonicalName, out var aliases)
            ? aliases
            : new[] { canonicalName };

        foreach (var candidate in candidates)
        {
            var field = fields.FirstOrDefault(item => HeaderMatches(item.Name, candidate));
            if (field is not null)
                return field.Value;
        }

        return "";
    }

    public void UpdateByAz(string az, ClaimRecord updatedRecord)
    {
        if (string.IsNullOrWhiteSpace(az))
            throw new ArgumentException("AZ is required.", nameof(az));

        EnsureWorkbookExists();
        dynamic? excel = null;
        dynamic? workbook = null;
        dynamic? sheet = null;
        dynamic? table = null;
        dynamic? headersRange = null;
        dynamic? dataRange = null;

        try
        {
            excel = Activator.CreateInstance(Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException("Microsoft Excel is not installed."))
                ?? throw new InvalidOperationException("Failed to start Microsoft Excel.");
            excel.Visible = false;
            excel.DisplayAlerts = false;
            workbook = excel.Workbooks.Open(_workbookPath, ReadOnly: false);
            var tableInfo = FindTable((object)workbook);
            sheet = tableInfo.Sheet;
            table = tableInfo.Table;
            headersRange = table.HeaderRowRange;
            dataRange = table.DataBodyRange;

            var headers = GetHeaderRow(headersRange!.Value2);
            if (dataRange is null)
                throw new InvalidOperationException($"The {_tableName} table has no data rows.");

            var values = dataRange.Value2;
            var rowIndex = FindRowIndex(headers, values, az);
            if (rowIndex < 0)
                throw new InvalidOperationException($"No claim found for AZ '{az}'.");

            for (var column = 0; column < headers.Length; column++)
            {
                var value = column < updatedRecord.Values.Length ? updatedRecord.Values[column] : null;
                dataRange.Cells[rowIndex + 1, column + 1].Value2 = ToExcelValue(value);
            }
            workbook.Save();
        }
        finally
        {
            CloseExcel(excel, workbook, sheet, table, headersRange, dataRange);
        }
    }

    private (object Sheet, object Table) FindTable(object workbookObject)
    {
        dynamic workbook = workbookObject;
        for (int sheetIndex = 1; sheetIndex <= workbook.Worksheets.Count; sheetIndex++)
        {
            dynamic candidateSheet = workbook.Worksheets[sheetIndex];
            for (int tableIndex = 1; tableIndex <= candidateSheet.ListObjects.Count; tableIndex++)
            {
                dynamic candidateTable = candidateSheet.ListObjects[tableIndex];
                if (string.Equals((string)candidateTable.Name, _tableName, StringComparison.OrdinalIgnoreCase))
                    return (candidateSheet, candidateTable);
                Release(candidateTable);
            }
            Release(candidateSheet);
        }

        throw new InvalidOperationException($"Excel table '{_tableName}' was not found.");
    }

    private static ClaimRecord? FindRecord(object? headerValues, object? dataValues,
        string fieldName, string query)
    {
        var headers = GetHeaderRow(headerValues);
        var searchColumn = FindHeaderIndexWithAliases(headers, fieldName);
        if (searchColumn < 0)
            throw new InvalidOperationException(
                $"The ClaimsData table must contain a '{fieldName}' column. Found columns: {string.Join(", ", headers)}");

        var rowIndex = FindRowIndex(headers, dataValues, searchColumn, query);
        if (rowIndex < 0)
            return null;

        return BuildRecord(headers, dataValues, rowIndex);
    }

    private static List<ClaimRecord> FindAllRecords(object? headerValues, object? dataValues,
        string fieldName, string query)
    {
        var headers = GetHeaderRow(headerValues);
        var searchColumn = FindHeaderIndexWithAliases(headers, fieldName);
        if (searchColumn < 0)
            throw new InvalidOperationException(
                $"The ClaimsData table must contain a '{fieldName}' column. Found columns: {string.Join(", ", headers)}");

        var records = new List<ClaimRecord>();
        foreach (var rowIndex in FindAllRowIndices(headers, dataValues, searchColumn, query))
            records.Add(BuildRecord(headers, dataValues, rowIndex));
        return records;
    }

    private static ClaimRecord BuildRecord(string[] headers, object? dataValues, int rowIndex)
    {
        var row = ToRow(dataValues, rowIndex);
        object? Value(string name) => GetValue(headers, row, name);
        return new ClaimRecord
        {
            Az = Value("AZ")?.ToString() ?? "",
            PolicyNumber = Value("Policy Number")?.ToString() ?? "",
            ClientId = Value("Client's ID Number")?.ToString() ?? "",
            Name = Value("Client Details")?.ToString() ?? "",
            LoanAmount = ParseDecimal(Value("Loan Amount")),
            LoanStartDate = ParseDate(Value("Disbursement Date")),
            IncidentDate = ParseDate(Value("Incident Date")),
            RowIndex = rowIndex,
            Headers = headers,
            Values = row
        };
    }

    private static int FindRowIndex(string[] headers, object? dataValues, string az)
    {
        var azColumn = FindHeaderIndex(headers, "AZ");
        if (azColumn < 0)
            throw new InvalidOperationException(
                $"The ClaimsData table must contain an AZ column. Found columns: {string.Join(", ", headers)}");

        return FindRowIndex(headers, dataValues, azColumn, az);
    }

    private static int FindRowIndex(string[] headers, object? dataValues, int searchColumn, string query)
    {
        var azColumn = FindHeaderIndex(headers, "AZ");
        var rowCount = GetDimension(dataValues, 0);
        for (var row = 0; row < rowCount; row++)
        {
            var value = GetArrayValue(dataValues, row, searchColumn)?.ToString()?.Trim() ?? "";
            var matches = searchColumn == azColumn
                ? string.Equals(value, query.Trim(), StringComparison.OrdinalIgnoreCase)
                : value.Contains(query.Trim(), StringComparison.OrdinalIgnoreCase);
            if (matches)
                return row;
        }
        return -1;
    }

    private static List<int> FindAllRowIndices(string[] headers, object? dataValues, int searchColumn, string query)
    {
        var azColumn = FindHeaderIndex(headers, "AZ");
        var trimmedQuery = query.Trim();
        var rowCount = GetDimension(dataValues, 0);
        var matches = new List<int>();
        for (var row = 0; row < rowCount; row++)
        {
            var value = GetArrayValue(dataValues, row, searchColumn)?.ToString()?.Trim() ?? "";
            var isMatch = searchColumn == azColumn
                ? string.Equals(value, trimmedQuery, StringComparison.OrdinalIgnoreCase)
                : value.Contains(trimmedQuery, StringComparison.OrdinalIgnoreCase);
            if (isMatch)
                matches.Add(row);
        }
        return matches;
    }

    private static void SetCell(dynamic dataRange, int row, string[] headers, string header, object? value)
    {
        var column = FindHeaderIndex(headers, header);
        if (column >= 0)
            dataRange.Cells[row + 1, column + 1].Value2 = ToExcelValue(value);
    }

    private static object? ToExcelValue(object? value)
    {
        if (value is DateTime date)
            return date.ToOADate();
        if (value is string text &&
            DateTime.TryParseExact(text.Trim(), "dd/MM/yyyy", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var parsedDate))
            return parsedDate.ToOADate();
        return value;
    }

    private static object? GetValue(string[] headers, object?[] row, string header)
    {
        var column = FindHeaderIndexWithAliases(headers, header);
        return column >= 0 && column < row.Length ? row[column] : null;
    }

    private static string[] ToRow(object? values, int row = 0) =>
        Enumerable.Range(0, GetDimension(values, 1)).Select(column => GetArrayValue(values, row, column)?.ToString() ?? "").ToArray();

    private static int GetDimension(object? values, int dimension)
    {
        if (values is not Array array)
            return values is null ? 0 : 1;
        return array.GetLength(dimension);
    }

    private static object? GetArrayValue(object? values, int row, int column)
    {
        if (values is object[,] matrix)
            return matrix[row + 1, column + 1];
        return row == 0 && column == 0 ? values : null;
    }

    private static decimal? ParseDecimal(object? value) =>
        decimal.TryParse(value?.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var parsed)
            ? parsed : null;

    private static DateTime? ParseDate(object? value)
    {
        if (value is null)
            return null;

        // Excel Value2 returns date cells as OLE Automation numbers.
        if (value is double serial || value is float || value is decimal || value is int || value is long)
        {
            var number = Convert.ToDouble(value, CultureInfo.InvariantCulture);
            if (number > 0)
                return DateTime.FromOADate(number).Date;
        }

        var text = value.ToString()?.Trim();
        if (string.IsNullOrWhiteSpace(text))
            return null;

        // Table rows are normalized to strings before mapping, so preserve
        // Excel serial dates in that representation as well.
        if (double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var textSerial) &&
            textSerial > 0)
            return DateTime.FromOADate(textSerial).Date;

        if (DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out var parsed) ||
            DateTime.TryParse(text, CultureInfo.CurrentCulture, DateTimeStyles.AllowWhiteSpaces, out parsed))
            return parsed.Date;

        return null;
    }

    private void EnsureWorkbookExists()
    {
        if (!File.Exists(_workbookPath))
            throw new FileNotFoundException("The local OneDrive workbook was not found.", _workbookPath);
    }

    private static void CloseExcel(dynamic? excel, dynamic? workbook, params dynamic?[] objects)
    {
        foreach (var item in objects.Reverse())
            Release(item);
        if (workbook is not null)
        {
            try { workbook.Close(false); } catch (COMException) { }
            Release(workbook);
        }
        if (excel is not null)
        {
            try { excel.Quit(); } catch (COMException) { }
            Release(excel);
        }
    }

    private static void Release(object? value)
    {
        if (value is not null && Marshal.IsComObject(value))
            Marshal.FinalReleaseComObject(value);
    }
}
