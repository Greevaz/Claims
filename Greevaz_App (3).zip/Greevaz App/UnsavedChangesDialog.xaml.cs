using System.Windows;

namespace ClaimsCalculatorApp
{
    public enum UnsavedChangesResult
    {
        Cancel,
        Save,
        Discard
    }

    /// <summary>
    /// Small modal prompt shown when the user tries to leave a tab (or close the app)
    /// with edits that have not been saved yet. Mirrors the "Save / Discard / Cancel"
    /// pattern used by most desktop apps.
    /// </summary>
    public partial class UnsavedChangesDialog : Window
    {
        public UnsavedChangesResult Result { get; private set; } = UnsavedChangesResult.Cancel;

        public UnsavedChangesDialog(string message)
        {
            InitializeComponent();
            TxtMessage.Text = message;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            Result = UnsavedChangesResult.Save;
            DialogResult = true;
        }

        private void BtnDiscard_Click(object sender, RoutedEventArgs e)
        {
            Result = UnsavedChangesResult.Discard;
            DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Result = UnsavedChangesResult.Cancel;
            DialogResult = false;
        }
    }
}
