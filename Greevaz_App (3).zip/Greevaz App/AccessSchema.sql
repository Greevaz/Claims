-- ClaimsData table schema for Access (Jet/ACE SQL syntax).
--
-- Run this from Access's own Query Designer (View > SQL View, on a new blank
-- query, in a *new empty* .accdb) — this is Jet SQL, not T-SQL, so it won't
-- run via SQL Server tools. It creates the table with short, ASCII column
-- names (Access caps field names at 64 characters, and several of the
-- original Excel headers are far longer than that — e.g. the "Claim Status"
-- column's full header is 132 characters). AccessClaimsService.cs's
-- ColumnMap maps each short name back to the original header text for
-- display, so nothing changes on screen.
--
-- Column type notes (based on inspecting Hollard_Database.xlsx directly):
--   - AZ is a plain whole number in every one of the 5,248 existing rows
--     (no letters, no blanks, no duplicates) — stored as LONG and used as
--     the primary key.
--   - "Date of Claim Decision Letter" and "Ex Gratia Submission Date" were
--     checked against all 5,248 rows of Hollard_Database.xlsx: every
--     non-blank value in both is a real date (no "N/A" or other stray text
--     survives in the current data), so both are stored as DATETIME.
--   - "Loan Balance Notification date" actually holds a Namibian-dollar
--     amount in every sampled row, not a date, despite its header — stored
--     as CURRENCY to match the real data rather than "fixing" the name.
--   - Text column sizes below are set generously above the longest existing
--     value in that column.

CREATE TABLE ClaimsData (
    AZ                            LONG PRIMARY KEY,
    PolicyNumber                  TEXT(50),
    ClientIdNumber                TEXT(50),
    ClientDetails                 TEXT(150),
    LoanAmount                    CURRENCY,
    DisbursementDate              DATETIME,
    Product                       TEXT(50),
    BenefitClaimed                TEXT(50),
    NotifiedDate                  DATETIME,
    IncidentDate                  DATETIME,
    DatePartialClaimSubmitted     DATETIME,
    DateCompletedClaimSubmitted   DATETIME,
    ClaimStatus                   TEXT(100),
    DateOfClaimDecisionLetter     DATETIME,
    AmountApproved                CURRENCY,
    ExGratiaSubmitted             TEXT(10),
    ExGratiaSubmissionDate        DATETIME,
    ExGratiaApprovedDeclined      TEXT(50),
    ExGratiaAmountRequested       CURRENCY,
    ExGratiaAmountReceived        CURRENCY,
    LoanBalanceNotificationAmount CURRENCY,
    ClaimAmount                   CURRENCY,
    MicroplusClaimedAmount        CURRENCY,
    TotalHollardAmountReceived    CURRENCY,
    DateClaimPaidByHollard        DATETIME,
    AmountRefunded                CURRENCY,
    DateRefundPaid                DATETIME,
    Comments                      TEXT(255)
);
