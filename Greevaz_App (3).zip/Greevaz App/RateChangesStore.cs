using System.IO;
using System.Text.Json;

namespace ClaimsCalculatorApp;

/// <summary>
/// Persists the Interest Rate Changes list.
///
/// This is saved to the shared network drive location
/// (P:\Public\__PostFin\Hollard Data Base\Interest Rate Changes\rate-changes.json)
/// alongside the Access database, rather than the SharePoint-synced claims
/// workbook folder it used to live in, and rather than next to the app's
/// own executable. Storing it on the network share means it survives app
/// updates and is the same list for every user/machine that can reach the
/// P: drive.
/// </summary>
public sealed class RateChangesStore
{
    private const string FileName = "rate-changes.json";

    // Preferred, shared location on the network drive.
    private static readonly string NetworkDirectory =
        @"P:\Public\__PostFin\Hollard Data Base\Interest Rate Changes";

    // Legacy locations from before rates lived on the network drive. Only
    // used once each, to migrate any existing data into the new file.
    private static readonly string LegacyBaseDirectoryFilePath = Path.Combine(
        AppContext.BaseDirectory,
        FileName);

    private readonly string _filePath;
    private readonly string? _legacySharePointFilePath;

    public RateChangesStore(GraphSettings? settings = null)
    {
        _filePath = Path.Combine(ResolveSharedDirectory(), FileName);

        var workbookDirectory = string.IsNullOrWhiteSpace(settings?.LocalWorkbookPath)
            ? null
            : Path.GetDirectoryName(settings.LocalWorkbookPath);
        _legacySharePointFilePath = string.IsNullOrWhiteSpace(workbookDirectory)
            ? null
            : Path.Combine(workbookDirectory, FileName);

        MigrateLegacyFileIfNeeded();
    }

    private static string ResolveSharedDirectory()
    {
        // 1) Preferred: the shared network drive location, next to the
        //    Access database, so the rate list is universal across every
        //    install and lives alongside the other shared app data.
        try
        {
            Directory.CreateDirectory(NetworkDirectory);
            return NetworkDirectory;
        }
        catch
        {
            // Fall through to the next option if the share isn't reachable
            // right now (e.g. offline / P: drive not mapped).
        }

        // 2) Fallback: a per-machine folder outside the app's own build
        //    output, so at minimum rates survive app updates even if the
        //    network drive isn't reachable yet.
        try
        {
            var programData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            var fallbackDirectory = Path.Combine(programData, "Greevaz Claims App");
            Directory.CreateDirectory(fallbackDirectory);
            return fallbackDirectory;
        }
        catch
        {
            // 3) Last resort: the old behaviour.
            return AppContext.BaseDirectory;
        }
    }

    private void MigrateLegacyFileIfNeeded()
    {
        if (File.Exists(_filePath))
            return;

        // Try the SharePoint-synced workbook folder first (most recent
        // previous location), then the very old app build-folder location.
        foreach (var legacyPath in new[] { _legacySharePointFilePath, LegacyBaseDirectoryFilePath })
        {
            if (string.IsNullOrWhiteSpace(legacyPath))
                continue;
            if (string.Equals(legacyPath, _filePath, StringComparison.OrdinalIgnoreCase))
                continue;
            if (!File.Exists(legacyPath))
                continue;

            try
            {
                var directory = Path.GetDirectoryName(_filePath);
                if (!string.IsNullOrWhiteSpace(directory))
                    Directory.CreateDirectory(directory);

                File.Copy(legacyPath, _filePath, overwrite: false);
                return;
            }
            catch
            {
                // Migration is best-effort; if it fails, try the next
                // legacy location, or the user just starts with an empty
                // shared list and can re-enter the rates.
            }
        }
    }

    public List<RateChange> Load()
    {
        if (!File.Exists(_filePath))
            return new List<RateChange>();

        var json = File.ReadAllText(_filePath);
        if (string.IsNullOrWhiteSpace(json))
            return new List<RateChange>();

        using var document = JsonDocument.Parse(json);
        List<RateChangeSetting> changes;

        if (document.RootElement.ValueKind == JsonValueKind.Array &&
            document.RootElement.EnumerateArray().Any(item =>
                item.ValueKind == JsonValueKind.Object &&
                item.TryGetProperty("Changes", out _)))
        {
            // Flatten the previous AZ-keyed format so existing settings remain usable.
            var legacyEntries = JsonSerializer.Deserialize<List<LegacyRateChangeSettings>>(json)
                ?? new List<LegacyRateChangeSettings>();
            changes = legacyEntries.SelectMany(entry => entry.Changes).ToList();
        }
        else
        {
            changes = JsonSerializer.Deserialize<List<RateChangeSetting>>(json)
                ?? new List<RateChangeSetting>();
        }

        return changes.Select(change => new RateChange
        {
            EffectiveDate = change.EffectiveDate,
            NewRatePercent = change.NewRatePercent
        }).ToList();
    }

    public void Save(IEnumerable<RateChange> changes)
    {
        var directory = Path.GetDirectoryName(_filePath)
            ?? throw new InvalidOperationException("Could not determine the settings directory.");
        Directory.CreateDirectory(directory);

        var settings = changes.Select(change => new RateChangeSetting
        {
            EffectiveDate = change.EffectiveDate,
            NewRatePercent = change.NewRatePercent
        }).ToList();

        var json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(_filePath, json);
    }

    private sealed class RateChangeSetting
    {
        public DateTime EffectiveDate { get; set; }
        public decimal NewRatePercent { get; set; }
    }

    private sealed class LegacyRateChangeSettings
    {
        public List<RateChangeSetting> Changes { get; set; } = new();
    }
}
