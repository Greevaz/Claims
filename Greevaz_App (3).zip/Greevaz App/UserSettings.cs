using System;
using System.IO;
using System.Text.Json;

namespace ClaimsCalculatorApp;

/// <summary>
/// A small per-user settings file, separate from appsettings.json.
///
/// appsettings.json ships with the app and is shared by all 3 users (and
/// overwritten every time the app is updated), so it's the wrong place for
/// something one person picks from the Settings screen. This instead lives
/// under the current Windows user's AppData folder, so:
///   - it persists across app restarts and updates,
///   - each user can point at a different path if they need to
///     (e.g. a differently-mapped drive letter),
///   - it never gets clobbered by redeploying the app folder.
///
/// When no override has been saved, AccessDatabasePath is null and callers
/// should fall back to appsettings.json's Graph:AccessDatabasePath.
/// </summary>
public sealed class UserSettings
{
    public string? AccessDatabasePath { get; set; }

    private static string FilePath =>
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "ClaimsCalculatorApp",
            "usersettings.json");

    public static UserSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath))
                return new UserSettings();

            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<UserSettings>(json) ?? new UserSettings();
        }
        catch
        {
            // Missing/corrupt user settings file — behave as if nothing was ever saved.
            return new UserSettings();
        }
    }

    public void Save()
    {
        var directory = Path.GetDirectoryName(FilePath)!;
        Directory.CreateDirectory(directory);
        var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(FilePath, json);
    }
}
