using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;

namespace ClaimsCalculatorApp
{
    public partial class ClientPickerWindow : Window
    {
        public ClaimRecord? SelectedClaim { get; private set; }

        public ClientPickerWindow(List<ClaimRecord> matches)
        {
            InitializeComponent();
            TxtPickerHeading.Text = $"{matches.Count} records match this search. Select the correct client:";
            GridMatches.ItemsSource = matches;
            if (matches.Count > 0)
                GridMatches.SelectedIndex = 0;
        }

        private void BtnSelect_Click(object sender, RoutedEventArgs e)
        {
            TrySelectAndClose();
        }

        private void GridMatches_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TrySelectAndClose();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void TrySelectAndClose()
        {
            if (GridMatches.SelectedItem is ClaimRecord claim)
            {
                SelectedClaim = claim;
                DialogResult = true;
            }
        }
    }
}
