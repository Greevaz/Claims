using System;
using System.IO;
using System.Linq;

namespace ClaimsCalculatorApp
{
    /// <summary>
    /// Handles automatic daily backups of ClaimsData.accdb.
    ///
    /// On every app launch (once the configured database path has been
    /// confirmed valid), <see cref="BackupIfNeeded"/> is called:
    ///   1. Ensures a "backups" folder exists in the same directory as the
    ///      database. If it doesn't exist yet, it's created.
    ///   2. Checks whether a backup with today's date already exists in that
    ///      folder. If one does, nothing happens.
    ///   3. Otherwise, copies the database into the backups folder with
    ///      today's date in the file name.
    /// </summary>
    public static class DatabaseBackupService
    {
        private const string DateStampFormat = "yyyy-MM-dd";

        // Oldest backups are deleted once the folder holds more than this
        // many files, to keep the backups folder from growing forever.
        private const int MaxBackups = 30;

        public static void BackupIfNeeded(string? databasePath)
        {
            if (string.IsNullOrWhiteSpace(databasePath) || !File.Exists(databasePath))
                return;

            var dbDirectory = Path.GetDirectoryName(databasePath);
            if (string.IsNullOrWhiteSpace(dbDirectory))
                return;

            var backupsFolder = Path.Combine(dbDirectory, "backups");

            // Step 1: make sure the backups folder exists.
            if (!Directory.Exists(backupsFolder))
                Directory.CreateDirectory(backupsFolder);

            // Step 2: has a backup already been made today?
            if (BackupExistsForToday(backupsFolder, databasePath))
                return;

            // Step 3: create today's backup.
            CreateBackup(backupsFolder, databasePath);

            // Step 4: enforce the retention cap, removing the oldest
            // backups first if there are now more than allowed.
            EnforceRetentionLimit(backupsFolder, databasePath);
        }

        private static bool BackupExistsForToday(string backupsFolder, string databasePath)
        {
            var todayStamp = DateTime.Today.ToString(DateStampFormat);
            var baseName = Path.GetFileNameWithoutExtension(databasePath);
            var searchPattern = $"{baseName}_*{todayStamp}*{Path.GetExtension(databasePath)}";

            return Directory.EnumerateFiles(backupsFolder, searchPattern).Any();
        }

        private static void CreateBackup(string backupsFolder, string databasePath)
        {
            var baseName = Path.GetFileNameWithoutExtension(databasePath);
            var extension = Path.GetExtension(databasePath);
            var todayStamp = DateTime.Today.ToString(DateStampFormat);

            var backupFileName = $"{baseName}_{todayStamp}{extension}";
            var backupPath = Path.Combine(backupsFolder, backupFileName);

            // Extremely unlikely (would require the file to appear between
            // the check above and here), but avoid overwriting just in case.
            var attempt = 1;
            while (File.Exists(backupPath))
            {
                backupFileName = $"{baseName}_{todayStamp}_{attempt}{extension}";
                backupPath = Path.Combine(backupsFolder, backupFileName);
                attempt++;
            }

            File.Copy(databasePath, backupPath, overwrite: false);
        }

        /// <summary>
        /// Keeps at most <see cref="MaxBackups"/> backup files in the
        /// backups folder. If there are more, the oldest ones (by last
        /// write time) are deleted until the count is back at the cap.
        /// </summary>
        private static void EnforceRetentionLimit(string backupsFolder, string databasePath)
        {
            var baseName = Path.GetFileNameWithoutExtension(databasePath);
            var extension = Path.GetExtension(databasePath);
            var searchPattern = $"{baseName}_*{extension}";

            var backups = new DirectoryInfo(backupsFolder)
                .GetFiles(searchPattern)
                .OrderBy(f => f.LastWriteTimeUtc)
                .ToList();

            var excessCount = backups.Count - MaxBackups;
            if (excessCount <= 0)
                return;

            foreach (var oldest in backups.Take(excessCount))
            {
                try
                {
                    oldest.Delete();
                }
                catch
                {
                    // Best-effort cleanup; if a file can't be deleted
                    // (locked, permissions, etc.) just leave it and move on.
                }
            }
        }
    }
}
