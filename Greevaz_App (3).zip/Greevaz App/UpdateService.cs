using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;

namespace ClaimsCalculatorApp
{
    public sealed record UpdateInfo(string Version, string DownloadUrl, string AssetFileName);

    /// <summary>
    /// Checks GitHub Releases for a newer build than the one currently
    /// running, and if the user accepts, downloads it and installs it.
    ///
    /// Windows won't let a running .exe/.dll overwrite itself, so the
    /// "install" step works like this:
    ///   1. Download the release's .zip asset and extract it to a temp folder.
    ///   2. Write a small PowerShell script that waits for this process to
    ///      exit, then copies the extracted files over the current install
    ///      folder, and finally relaunches the app.
    ///   3. Start that script as an independent process and shut this app down.
    ///
    /// Requirements on the GitHub side: each release must have a single
    /// .zip asset containing the published app (the contents of the
    /// publish/output folder), and the release's tag name should be a plain
    /// version number, e.g. "1.3.0" or "v1.3.0".
    /// </summary>
    public static class UpdateService
    {
        public static async Task<UpdateInfo?> CheckForUpdateAsync(UpdateSettings settings)
        {
            if (!settings.Enabled ||
                string.IsNullOrWhiteSpace(settings.GitHubOwner) ||
                string.IsNullOrWhiteSpace(settings.GitHubRepo))
            {
                return null;
            }

            using var client = new HttpClient();
            client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("ClaimsCalculatorApp", "1.0"));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github+json"));

            var url = $"https://api.github.com/repos/{settings.GitHubOwner}/{settings.GitHubRepo}/releases/latest";
            using var response = await client.GetAsync(url);
            if (!response.IsSuccessStatusCode)
                return null;

            using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            var root = json.RootElement;

            var tagName = root.GetProperty("tag_name").GetString() ?? "";
            var latestVersionText = tagName.TrimStart('v', 'V');

            if (!Version.TryParse(latestVersionText, out var latestVersion))
                return null;

            var currentVersion = Assembly.GetExecutingAssembly().GetName().Version ?? new Version(0, 0, 0, 0);
            if (latestVersion <= currentVersion)
                return null;

            if (!root.TryGetProperty("assets", out var assets))
                return null;

            var asset = assets.EnumerateArray().FirstOrDefault(a =>
            {
                var name = a.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "";
                return name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) &&
                       (string.IsNullOrWhiteSpace(settings.AssetNameContains) ||
                        name.Contains(settings.AssetNameContains, StringComparison.OrdinalIgnoreCase));
            });

            if (asset.ValueKind != JsonValueKind.Object)
                return null;

            var downloadUrl = asset.GetProperty("browser_download_url").GetString();
            var assetName = asset.GetProperty("name").GetString();
            if (string.IsNullOrWhiteSpace(downloadUrl) || string.IsNullOrWhiteSpace(assetName))
                return null;

            return new UpdateInfo(latestVersionText, downloadUrl, assetName);
        }

        /// <summary>
        /// Downloads the update zip, extracts it, writes and launches the
        /// installer script, then shuts this app down so the script can
        /// replace its files. Call this from the UI thread; it does not
        /// return normally on success (the app exits).
        /// </summary>
        public static async Task DownloadAndInstallAsync(UpdateInfo update)
        {
            var installDir = AppContext.BaseDirectory.TrimEnd('\\', '/');
            var exePath = Process.GetCurrentProcess().MainModule?.FileName
                ?? Path.Combine(installDir, "ClaimsCalculatorApp.exe");
            var exeName = Path.GetFileName(exePath);

            var tempRoot = Path.Combine(Path.GetTempPath(), "ClaimsCalculatorApp_Update_" + Guid.NewGuid().ToString("N"));
            var zipPath = Path.Combine(tempRoot, update.AssetFileName);
            var extractDir = Path.Combine(tempRoot, "extracted");
            Directory.CreateDirectory(tempRoot);
            Directory.CreateDirectory(extractDir);

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("ClaimsCalculatorApp", "1.0"));
                var bytes = await client.GetByteArrayAsync(update.DownloadUrl);
                await File.WriteAllBytesAsync(zipPath, bytes);
            }

            ZipFile.ExtractToDirectory(zipPath, extractDir, overwriteFiles: true);

            // If the release zip has a single top-level folder wrapping the
            // actual build output, step into it so files land directly in
            // the install directory rather than one level too deep.
            var entries = Directory.GetFileSystemEntries(extractDir);
            if (entries.Length == 1 && Directory.Exists(entries[0]))
                extractDir = entries[0];

            var scriptPath = Path.Combine(tempRoot, "install-update.ps1");
            var currentPid = Environment.ProcessId;

            var script = $$"""
                $ErrorActionPreference = 'SilentlyContinue'
                try { Wait-Process -Id {{currentPid}} -Timeout 30 } catch {}
                Start-Sleep -Seconds 1

                $source = "{{extractDir}}"
                $destination = "{{installDir}}"

                Copy-Item -Path (Join-Path $source '*') -Destination $destination -Recurse -Force

                Start-Process -FilePath (Join-Path $destination "{{exeName}}")

                Start-Sleep -Seconds 2
                Remove-Item -Path "{{tempRoot}}" -Recurse -Force
                """;

            await File.WriteAllTextAsync(scriptPath, script);

            var psi = new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = $"-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"{scriptPath}\"",
                UseShellExecute = true,
                CreateNoWindow = true
            };
            Process.Start(psi);

            System.Windows.Application.Current.Shutdown();
        }
    }
}
