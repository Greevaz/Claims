using System.IO;
using System.Text.Json;

namespace ClaimsCalculatorApp;

/// <summary>
/// Persists the Interest Rate Changes list.
///
/// This is saved to the same shared, synced folder as the claims workbook
/// (GraphSettings.LocalWorkbookPath) rather than next to the app's own
/// executable. The old behaviour stored it in the build/publish output
/// folder, which meant every new build or update landed in a fresh folder
/// and the rates looked "lost". Storing it in the shared claims folder
/// instead means it survives app updates and is the same list for every
/// user/machine that points at that shared folder.
/// </summary>
public sealed class RateChangesStore
{
    private const string FileName = "rate-changes.json";

    // Legacy location from before rates were made shared/universal. Only
    // used once, to migrate any existing data into the new shared file.
    private static readonly string LegacyFilePath = Path.Combine(
        AppContext.BaseDirectory,
        FileName);

    private readonly string _filePath;

    public RateChangesStore(GraphSettings? settings = null)
    {
        _filePath = Path.Combine(ResolveSharedDirectory(settings), FileName);
        MigrateLegacyFileIfNeeded();
    }

    private static string ResolveSharedDirectory(GraphSettings? settings)
    {
        // 1) Preferred: the same shared/synced folder the claims workbook
        //    lives in, so the rate list is universal across every install.
        var workbookPath = settings?.LocalWorkbookPath;
        if (!string.IsNullOrWhiteSpace(workbookPath))
        {
            var workbookDirectory = Path.GetDirectoryName(workbookPath);
            if (!string.IsNullOrWhiteSpace(workbookDirectory))
            {
                try
                {
                    Directory.CreateDirectory(workbookDirectory);
                    return workbookDirectory;
                }
                catch
                {
                    // Fall through to the next option if the shared folder
                    // isn't reachable (e.g. offline / not yet synced).
                }
            }
        }

        // 2) Fallback: a per-machine folder outside the app's own build
        //    output, so at minimum rates survive app updates even if the
        //    shared workbook path isn't configured yet.
        try
        {
            var programData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
            var fallbackDirectory = Path.Combine(programData, "Greevaz Claims App");
            Directory.CreateDirectory(fallbackDirectory);
            return fallbackDirectory;
        }
        catch
        {
            // 3) Last resort: the old behaviour.
            return AppContext.BaseDirectory;
        }
    }

    private void MigrateLegacyFileIfNeeded()
    {
        try
        {
            if (string.Equals(_filePath, LegacyFilePath, StringComparison.OrdinalIgnoreCase))
                return;

            if (File.Exists(_filePath))
                return;

            if (!File.Exists(LegacyFilePath))
                return;

            var directory = Path.GetDirectoryName(_filePath);
            if (!string.IsNullOrWhiteSpace(directory))
                Directory.CreateDirectory(directory);

            File.Copy(LegacyFilePath, _filePath, overwrite: false);
        }
        catch
        {
            // Migration is best-effort; if it fails the user just starts
            // with an empty shared list and can re-enter the rates.
        }
    }

    public List<RateChange> Load()
    {
        if (!File.Exists(_filePath))
            return new List<RateChange>();

        var json = File.ReadAllText(_filePath);
        if (string.IsNullOrWhiteSpace(json))
            return new List<RateChange>();

        using var document = JsonDocument.Parse(json);
        List<RateChangeSetting> changes;

        if (document.RootElement.ValueKind == JsonValueKind.Array &&
            document.RootElement.EnumerateArray().Any(item =>
                item.ValueKind == JsonValueKind.Object &&
                item.TryGetProperty("Changes", out _)))
        {
            // Flatten the previous AZ-keyed format so existing settings remain usable.
            var legacyEntries = JsonSerializer.Deserialize<List<LegacyRateChangeSettings>>(json)
                ?? new List<LegacyRateChangeSettings>();
            changes = legacyEntries.SelectMany(entry => entry.Changes).ToList();
        }
        else
        {
            changes = JsonSerializer.Deserialize<List<RateChangeSetting>>(json)
                ?? new List<RateChangeSetting>();
        }

        return changes.Select(change => new RateChange
        {
            EffectiveDate = change.EffectiveDate,
            NewRatePercent = change.NewRatePercent
        }).ToList();
    }

    public void Save(IEnumerable<RateChange> changes)
    {
        var directory = Path.GetDirectoryName(_filePath)
            ?? throw new InvalidOperationException("Could not determine the settings directory.");
        Directory.CreateDirectory(directory);

        var settings = changes.Select(change => new RateChangeSetting
        {
            EffectiveDate = change.EffectiveDate,
            NewRatePercent = change.NewRatePercent
        }).ToList();

        var json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(_filePath, json);
    }

    private sealed class RateChangeSetting
    {
        public DateTime EffectiveDate { get; set; }
        public decimal NewRatePercent { get; set; }
    }

    private sealed class LegacyRateChangeSettings
    {
        public List<RateChangeSetting> Changes { get; set; } = new();
    }
}
