using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using UglyToad.PdfPig;
using UglyToad.PdfPig.Content;

namespace ClaimsCalculatorApp
{
    /// <summary>
    /// One row extracted from the statement's transaction table.
    /// </summary>
    public sealed class ExtractedTransaction
    {
        public DateTime Date { get; set; }           // Effect date
        public DateTime? ActualDate { get; set; }
        public string RefNo { get; set; } = "";
        public string BatchNo { get; set; } = "";
        public string Code { get; set; } = "";
        public string Description { get; set; } = "";
        public decimal? Debit { get; set; }
        public decimal? Credit { get; set; }
        public decimal? Balance { get; set; }
    }

    /// <summary>
    /// Everything pulled out of one imported statement PDF.
    /// </summary>
    public sealed class StatementImportResult
    {
        public string? ReferenceNo { get; set; }
        public string? AccountNo { get; set; }
        public string? AccountNumber { get; set; }   // Best single value to use as the app's AZ field
        public string? ClientName { get; set; }
        public DateTime? StartDate { get; set; }
        public decimal? AmountFinanced { get; set; }
        public List<ExtractedTransaction> Transactions { get; } = new();
    }

    /// <summary>
    /// Reads a PostFin-style "Loan Account Statement" PDF and extracts the
    /// account reference, a few header fields, and every transaction row.
    ///
    /// This targets the fixed column layout:
    ///   Effect date | Actual Date | Ref no | Batch no | Code | Transaction | Debit | Credit | Balance
    ///
    /// Because a PDF's underlying text order rarely matches its visual
    /// layout, every word is first grouped back into rows by its Y position
    /// on the page, then columns are located by finding the "Debit",
    /// "Credit", "Balance" (etc.) header row and using its word X-positions
    /// as column boundaries. Every other word on a data row is then bucketed
    /// into the nearest column by X position, which reconstructs the table
    /// correctly regardless of raw text order.
    ///
    /// If a statement uses different column headers or order, update
    /// ColumnNames below to match.
    /// </summary>
    public static class StatementImportService
    {
        private static readonly string[] ColumnNames =
        {
            "Effect", "Actual", "Ref", "Batch", "Code", "Transaction", "Debit", "Credit", "Balance"
        };

        private static readonly Regex DateToken = new(
            @"^\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}$", RegexOptions.Compiled);

        public static StatementImportResult Parse(string pdfPath)
        {
            var result = new StatementImportResult();
            double[]? boundaries = null;
            double[]? anchors = null;

            using var document = PdfDocument.Open(pdfPath);
            foreach (var page in document.GetPages())
            {
                var rows = GroupWordsIntoRows(page);

                ExtractHeaderFields(rows, result);

                var headerAnchors = TryFindColumnAnchors(rows);
                if (headerAnchors is not null)
                {
                    anchors = headerAnchors;
                    boundaries = ComputeBoundaries(anchors);
                }

                if (anchors is null || boundaries is null)
                    continue; // haven't located the transaction table yet on this/previous pages

                foreach (var row in rows)
                {
                    var transaction = TryParseDataRow(row, anchors, boundaries);
                    if (transaction is not null)
                        result.Transactions.Add(transaction);
                }
            }

            result.AccountNumber = result.ReferenceNo ?? result.AccountNo;
            return result;
        }

        /// <summary>
        /// Groups a page's words into visual rows using their Y position,
        /// then orders each row left-to-right, so multi-column rows come
        /// back out in true reading order even though PDF text extraction
        /// order often doesn't match the visual layout.
        /// </summary>
        private static List<List<Word>> GroupWordsIntoRows(Page page)
        {
            const double yTolerance = 3.0;
            var rows = new List<List<Word>>();

            foreach (var word in page.GetWords().OrderByDescending(w => w.BoundingBox.Top))
            {
                var row = rows.FirstOrDefault(r =>
                    Math.Abs(r[0].BoundingBox.Top - word.BoundingBox.Top) <= yTolerance);

                if (row is null)
                {
                    row = new List<Word>();
                    rows.Add(row);
                }

                row.Add(word);
            }

            foreach (var row in rows)
                row.Sort((a, b) => a.BoundingBox.Left.CompareTo(b.BoundingBox.Left));

            return rows;
        }

        /// <summary>
        /// Finds the transaction table's header row (the one row that
        /// contains "Debit", "Credit" and "Balance" as literal words) and
        /// returns the left-X position of each of the 9 expected columns,
        /// in column order.
        /// </summary>
        private static double[]? TryFindColumnAnchors(List<List<Word>> rows)
        {
            foreach (var row in rows)
            {
                bool Has(string label) => row.Any(w => string.Equals(w.Text, label, StringComparison.OrdinalIgnoreCase));

                if (!Has("Debit") || !Has("Credit") || !Has("Balance") || !Has("Transaction"))
                    continue;

                var anchors = new double[ColumnNames.Length];
                var found = true;
                for (var i = 0; i < ColumnNames.Length; i++)
                {
                    var word = row.FirstOrDefault(w => string.Equals(w.Text, ColumnNames[i], StringComparison.OrdinalIgnoreCase));
                    if (word is null)
                    {
                        found = false;
                        break;
                    }
                    anchors[i] = word.BoundingBox.Left;
                }

                if (found)
                    return anchors.OrderBy(x => x).ToArray();
            }

            return null;
        }

        private static double[] ComputeBoundaries(double[] anchorsSorted)
        {
            var boundaries = new double[anchorsSorted.Length - 1];
            for (var i = 0; i < boundaries.Length; i++)
                boundaries[i] = (anchorsSorted[i] + anchorsSorted[i + 1]) / 2.0;
            return boundaries;
        }

        private static int ColumnIndexFor(double x, double[] boundaries)
        {
            var index = 0;
            for (var i = 0; i < boundaries.Length; i++)
            {
                if (x >= boundaries[i]) index = i + 1;
                else break;
            }
            return index;
        }

        private static ExtractedTransaction? TryParseDataRow(List<Word> row, double[] anchors, double[] boundaries)
        {
            if (row.Count == 0)
                return null;

            var buckets = new List<Word>[anchors.Length];
            for (var i = 0; i < buckets.Length; i++)
                buckets[i] = new List<Word>();

            foreach (var word in row)
                buckets[ColumnIndexFor(word.BoundingBox.Left, boundaries)].Add(word);

            var effectDateText = string.Join(" ", buckets[0].Select(w => w.Text)).Trim();
            if (!DateToken.IsMatch(effectDateText) || !TryParseDate(effectDateText, out var effectDate))
                return null; // not a transaction row (e.g. header, totals, notes)

            DateTime? actualDate = null;
            var actualDateText = string.Join(" ", buckets[1].Select(w => w.Text)).Trim();
            if (TryParseDate(actualDateText, out var parsedActual))
                actualDate = parsedActual;

            return new ExtractedTransaction
            {
                Date = effectDate,
                ActualDate = actualDate,
                RefNo = string.Join(" ", buckets[2].Select(w => w.Text)).Trim(),
                BatchNo = string.Join(" ", buckets[3].Select(w => w.Text)).Trim(),
                Code = string.Join(" ", buckets[4].Select(w => w.Text)).Trim(),
                Description = string.Join(" ", buckets[5].Select(w => w.Text)).Trim(),
                Debit = ParseAmountFromBucket(buckets[6]),
                Credit = ParseAmountFromBucket(buckets[7]),
                Balance = ParseAmountFromBucket(buckets[8])
            };
        }

        private static decimal? ParseAmountFromBucket(List<Word> words)
        {
            if (words.Count == 0)
                return null;

            var text = string.Join("", words.Select(w => w.Text));
            var match = Regex.Match(text, @"[\d,]+\.\d{2}");
            if (!match.Success)
                return null;

            if (!decimal.TryParse(match.Value.Replace(",", ""), NumberStyles.Number, CultureInfo.InvariantCulture, out var value))
                return null;

            return text.Contains('(') ? -value : value;
        }

        /// <summary>
        /// Pulls the handful of header/summary fields (reference no, account
        /// no, client name, start date, amount financed) out of the
        /// statement's top summary box. Relies on the same row-grouping as
        /// the transaction table, so label and value stay adjacent even
        /// though the box is laid out as a small multi-column grid.
        /// </summary>
        private static void ExtractHeaderFields(List<List<Word>> rows, StatementImportResult result)
        {
            var lines = rows.Select(r => string.Join(" ", r.Select(w => w.Text))).ToList();

            for (var i = 0; i < lines.Count; i++)
            {
                var line = lines[i];

                if (result.ReferenceNo is null)
                {
                    var m = Regex.Match(line, @"Reference\s*no\.?\s+([A-Za-z0-9][A-Za-z0-9\-\/]{2,20})", RegexOptions.IgnoreCase);
                    if (m.Success) result.ReferenceNo = m.Groups[1].Value.Trim();
                }

                if (result.AccountNo is null)
                {
                    var m = Regex.Match(line, @"\bAccount\s*No\b\s+([A-Za-z0-9][A-Za-z0-9\-\/]{0,20})", RegexOptions.IgnoreCase);
                    if (m.Success) result.AccountNo = m.Groups[1].Value.Trim();
                }

                if (result.ClientName is null
                    && Regex.IsMatch(line, @"^Client\s+details$", RegexOptions.IgnoreCase)
                    && i + 1 < lines.Count)
                {
                    // The name row can carry other fields after it on the same visual
                    // row (e.g. "Willemina Eichas ID no 79092910899") — cut at the
                    // first known trailing label rather than assuming the whole row.
                    var candidate = Regex.Split(lines[i + 1], @"\b(ID\s*no|Reference\s*no)\b", RegexOptions.IgnoreCase)[0].Trim();
                    if (candidate.Length > 0 && !candidate.StartsWith("P.O", StringComparison.OrdinalIgnoreCase))
                        result.ClientName = candidate;
                }

                if (result.StartDate is null)
                {
                    var m = Regex.Match(line, @"Start date\s+(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4})", RegexOptions.IgnoreCase);
                    if (m.Success && TryParseDate(m.Groups[1].Value, out var d)) result.StartDate = d;
                }

                if (result.AmountFinanced is null)
                {
                    var m = Regex.Match(line, @"Amount financed\s+\$?\s*([\d,]+\.\d{2})", RegexOptions.IgnoreCase);
                    if (m.Success && decimal.TryParse(m.Groups[1].Value.Replace(",", ""), NumberStyles.Number, CultureInfo.InvariantCulture, out var v))
                        result.AmountFinanced = v;
                }
            }
        }

        private static bool TryParseDate(string text, out DateTime date)
        {
            string[] formats =
            {
                "d-M-yyyy", "dd-MM-yyyy", "d/M/yyyy", "dd/MM/yyyy",
                "d.M.yyyy", "dd.MM.yyyy", "d-M-yy", "dd-MM-yy"
            };

            return DateTime.TryParseExact(text, formats, CultureInfo.InvariantCulture,
                       DateTimeStyles.None, out date)
                   || DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.None, out date);
        }
    }
}
